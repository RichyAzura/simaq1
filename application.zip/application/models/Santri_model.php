<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Santri_model extends CI_Model {
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}


	// untuk list data santri
	public function listing(){
		$this->db->select('*');
		$this->db->from('santri');
		$this->db->order_by('nis', 'asc');
		$query = $this->db->get();
		return $query->result();

	}
	
	// Detail
	public function detail($nis){
		$this->db->select('*');
		$this->db->from('santri');
		$this->db->where('nis', $nis);
		$this->db->order_by('nis', 'asc');
		$query = $this->db->get();
		return $query->row();
	}

	public function add($data){
		$this->db->insert('santri', $data);
	}
	
		// Edit
	public function edit($data){
		$this->db->where('nis', $data['nis']);	
		$this->db->update('santri', $data);
	}


	// Delete
	public function delete($data){
		$this->db->where('nis', $data['nis']);
		$this->db->delete('santri', $data);
	}

	public function get_count(){
		$sql = "SELECT count(nis) as nis from santri";
		$result = $this->db->query($sql);
		return $result->row()->nis;
	}

	public function update($tablename, $data, $where){
		$res = $this->db->update($tablename, $data, $where);
		return $res;
	}


	

}

/* End of file Santri_model.php */
/* Location: ./application/models/Santri_model.php */