<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kelas_santri_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

    public function add2($data2){
        $this->db->insert('kelas_santri', $data2);
    }


	// Listing all Kelas Santri
	public function listing(){
		$this->db->select('kelas_santri.id_kelassantri, kelas_santri.id_kelas, kelas_santri.id_jadwal, kelas_santri.kode_periode, kelas_santri.nis, kelas.kode_kelas, santri.nama_santri, jadwal.kode_jadwal, jadwal.id_jadwal, periode.semester, periode.thn_akademik');
		$this->db->from('kelas_santri');
		$this->db->join('kelas', 'kelas.id_kelas = kelas_santri.id_kelas', 'left');
		$this->db->join('santri', 'santri.nis = kelas_santri.nis', 'left');
		$this->db->join('jadwal', 'jadwal.id_jadwal = kelas_santri.id_jadwal', 'left');
		$this->db->join('periode', 'periode.kode_periode = kelas_santri.kode_periode', 'left');
		$this->db->order_by('id_kelassantri', 'asc');
		$query = $this->db->get();
		return $query->result();
	}

	// Detail Kelas Santri
	public function detail($id_kelassantri){
		$this->db->select('*');
		 $this->db->select('(SELECT santri.nama_santri from kelas_santri, santri WHERE kelas_santri.nis = santri.nis AND kelas_santri.id_kelassantri  = '.$id_kelassantri.') as sa');
		 $this->db->select('(SELECT jadwal.kode_jadwal from kelas_santri, jadwal WHERE kelas_santri.id_jadwal = jadwal.id_jadwal AND kelas_santri.id_kelassantri  = '.$id_kelassantri.') kj ');
          $this->db->select('(SELECT periode.semester from kelas_santri, periode WHERE kelas_santri.kode_periode = periode.kode_periode AND kelas_santri.id_kelassantri  = '.$id_kelassantri.') as sm');
		 $this->db->select('(SELECT periode.thn_akademik from kelas_santri, periode WHERE kelas_santri.kode_periode = periode.kode_periode AND kelas_santri.id_kelassantri  = '.$id_kelassantri.') as th');
		 $this->db->select('(SELECT kelas.kode_kelas from kelas_santri, kelas WHERE kelas_santri.id_kelas = kelas.id_kelas AND kelas_santri.id_kelassantri  = '.$id_kelassantri.') as kk');
		$this->db->from('kelas_santri');
		$this->db->where('kelas_santri.id_kelassantri', $id_kelassantri);
		$this->db->order_by('id_kelassantri', 'asc');
		$query = $this->db->get();
		return $query->row();
	}

	 public function getDetailPenentuanKelas($id_registrasi, $limit = 0)
    {
        $sql = "SELECT t1.id_kelassantri, t2.jk, t2.kelas, t2.totjuz, t2.nama_santri, t3.kode_jadwal, t4.semester, t4.thn_akademik, t5.kode_kelas
                FROM kelas_santri t1
                LEFT JOIN periode t4 ON (t1.kode_periode = t4.kode_periode)
                LEFT JOIN santri t2 ON (t1.nis = t2.nis)
                LEFT JOIN jadwal t3 ON (t1.id_jadwal = t3.id_jadwal)
                LEFT JOIN kelas t5 ON (t1.id_kelas = t5.id_kelas)";

        if ($id_registrasi) {
            $sql .= " WHERE id_registrasi = ?";
        }
        if ($limit) {
            $sql .= " ORDER BY t3.kode_jadwal LIMIT ".$limit;
        }
        $query = $this->db->query($sql, $id_registrasi);
        return $query->result_array();
    }

     public function getDetailPenentuanKelasbyJadwal($id_jadwal, $jk)
    {
        $sql = "SELECT t1.id_kelassantri,t2.jk, t2.kelas, t2.nama_santri, t2.totjuz,t3.id_jadwal, t3.kode_jadwal, t4.semester, t4.thn_akademik, t5.kode_kelas
                FROM kelas_santri t1
                 LEFT JOIN periode t4 ON (t1.kode_periode = t4.kode_periode)
                LEFT JOIN santri t2 ON (t1.nis = t2.nis)
                LEFT JOIN jadwal t3 ON (t1.id_jadwal = t3.id_jadwal)
                LEFT JOIN kelas t5 ON (t1.id_kelas = t5.id_kelas)
                WHERE  t3.id_jadwal = ?
                AND t2.jk = ?";
        $query = $this->db->query($sql, array($id_jadwal, $jk));
        return $query->result_array();
    }


	//Edit Kelas Santri
	public function edit($data){
		$this->db->where('id_kelassantri', $data['id_kelassantri']);	
		$this->db->update('kelas_santri', $data);
		
	}

	// Delete Kelas Santri
	public function delete($data){
		$this->db->where('id_kelassantri', $data['id_kelassantri']);
		$this->db->delete('kelas_santri', $data);
	}

}

/* End of file Kelas_santri_model.php */
/* Location: ./application/models/Kelas_santri_model.php */