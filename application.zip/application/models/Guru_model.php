<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Guru_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	// untuk list data guru
	public function listing(){
		$this->db->select('*');
		$this->db->from('guru');
		$this->db->order_by('id_guru', 'asc');
		$query = $this->db->get();
		return $query->result();

	}
	
	// Detail
	public function detail($id_guru){
		$this->db->select('*');
		$this->db->from('guru');
		$this->db->where('id_guru', $id_guru);
		$this->db->order_by('id_guru', 'asc');
		$query = $this->db->get();
		return $query->row();
	}

	public function add($data){
		$this->db->insert('guru', $data);
	}
	
		// Edit
	public function edit($data){
		$this->db->where('id_guru', $data['id_guru']);	
		$this->db->update('guru', $data);
	}

	// Delete
	public function delete($data){
		$this->db->where('id_guru', $data['id_guru']);
		$this->db->delete('guru', $data);
	}

}

/* End of file Guru_model.php */
/* Location: ./application/models/Guru_model.php */