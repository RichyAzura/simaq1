<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Login_model extends CI_Model {

	 function login($username,$password,$level)
  {
  if ($level == "Admin" || $level == "Bendahara" || $level == "Wakbid" || $level == "Guru" || $level == "Ketua" || $level == "Santri") {
  			  $this->db->select('*');
          $this->db->from('user');       
			  	$this->db->where('username',$username);
          $this->db->where('password',sha1($password));
          $this->db->where('level',($level));
          $this->db->limit(1);
  				$querycek = $this->db->get();

  			 if ($querycek->num_rows()==1) {
                return $querycek->result();
            } else {
              $this->db->select('*');
              $this->db->from('user');       
			  			$this->db->where('username',$username);
              $this->db->where('password',sha1($password));
              $this->db->where('level',($level));
              $this->db->limit(1);

			$query = $this->db->get();
			 if ($query->num_rows()==1) {
                return $query->result();
              } else {
                return false;
              }
            }
            
}
}
}


/* End of file Login_model.php */
/* Location: ./application/models/Login_model.php */