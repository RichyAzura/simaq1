<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pertemuan_model extends CI_Model {
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	// Listing all Pertemuan
	public function listing(){
		$this->db->select('pertemuan.id_kelas, pertemuan.tgl, pertemuan.id_pertemuan
		 , kelas.kode_kelas, user.id_guru');
		$this->db->from('pertemuan');
		$this->db->join('kelas', 'kelas.id_kelas = pertemuan.id_kelas', 'left');
		$this->db->join('guru', 'guru.id_guru = kelas.id_guru', 'left');
		$this->db->join('user', 'user.id_guru = guru.id_guru', 'left');
		$this->db->where('user.id_guru=', $this->session->userdata('id_guru'));
		$this->db->order_by('id_pertemuan', 'asc');
		$query = $this->db->get();
		return $query->result();
	}


	public function detail($id_pertemuan){
		$this->db->select('*');
		$this->db->select('(SELECT kelas.kode_kelas from pertemuan, kelas WHERE pertemuan.id_kelas = kelas.id_kelas AND pertemuan.id_pertemuan = '.$id_pertemuan.') as kk');
		$this->db->from('pertemuan');
		$this->db->where('id_pertemuan', $id_pertemuan);
		$this->db->order_by('id_pertemuan', 'asc');
		$query = $this->db->get();
		return $query->row();
	}


	public function add($data){
		$this->db->insert('pertemuan', $data);
	}


	public function edit($data){
		$this->db->where('id_pertemuan', $data['id_pertemuan']);	
		$this->db->update('pertemuan', $data);
	}


	public function delete($data){
		$this->db->where('id_pertemuan', $data['id_pertemuan']);
		$this->db->delete('pertemuan', $data);
	}

}

/* End of file Pertemuan_model.php */
/* Location: ./application/models/Pertemuan_model.php */