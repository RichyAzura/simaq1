<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Periode_model extends CI_Model {

	// untuk load database
	public function __construct()
	{
		parent::__construct();
		
		$this->load->database();
	}

	// untuk list data periode
	public function listing(){
		$this->db->select('*');
		$this->db->from('periode');
		$this->db->order_by('kode_periode', 'asc');
		$query = $this->db->get();
		return $query->result();

	}
	
	// Detail
	public function detail($kode_periode){
		$this->db->select('*');
		$this->db->from('periode');
		$this->db->where('kode_periode', $kode_periode);
		$this->db->order_by('kode_periode', 'asc');
		$query = $this->db->get();
		return $query->row();
	}

	public function add($data){
		$this->db->insert('periode', $data);
	}
	
		// Edit
	public function edit($data){
		$this->db->where('kode_periode', $data['kode_periode']);	
		$this->db->update('periode', $data);
	}

	// Delete
	public function delete($data){
		$this->db->where('kode_periode', $data['kode_periode']);
		$this->db->delete('periode', $data);
	}

}

/* End of file periode_model.php */
/* Location: ./application/models/periode_model.php */