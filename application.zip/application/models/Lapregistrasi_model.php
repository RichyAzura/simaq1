<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lapregistrasi_model extends CI_Model {
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function getListRegistrasi()
    {
      $query = $this->db->query('SELECT * FROM registrasi');
        return $query->result_array();
    }

     public function getDetailRegistrasi($id_registrasi, $limit = 0)
    {
 
        $sql = "SELECT t1.id_registrasi, t2.nama_tipe, t3.semester, t3.thn_akademik, t1.tgl, t4.nama_santri, t4.kelas,t5.kode_jadwal, t1.status,
                    DATE_FORMAT(t1.tgl, '%b') `month`, DATE_FORMAT(t1.tgl, '%d') `day`
                FROM registrasi t1
                LEFT JOIN tipe t2 ON (t1.kode_tipe = t2.kode_tipe)
                LEFT JOIN periode t3 ON (t1.kode_periode = t3.kode_periode)
                LEFT JOIN santri t4 ON (t1.nis = t4.nis)
                LEFT JOIN jadwal t5 ON (t1.id_jadwal = t5.id_jadwal)";
        if ($id_registrasi) {
            $sql .= " WHERE t1.id_registrasi = ?";
        }
        if ($limit) {
            $sql .= " ORDER BY t1.tgl LIMIT ".$limit;
        }
        $query = $this->db->query($sql, $id_registrasi);
        return $query->result_array();
    }

     public function getDetailRegistrasiByDate($tahun, $bulan, $status)
    {
        $sql = "SELECT t1.id_registrasi, t2.nama_tipe,t3.semester, t3.thn_akademik, t1.tgl, t4.nama_santri,t4.kelas,t5.kode_jadwal, t1.status,
                    DATE_FORMAT(t1.tgl, '%b') `month`, DATE_FORMAT(t1.tgl, '%d') `day`
                FROM registrasi t1
                LEFT JOIN tipe t2 ON (t1.kode_tipe = t2.kode_tipe)
                LEFT JOIN periode t3 ON (t1.kode_periode = t3.kode_periode)
                LEFT JOIN santri t4 ON (t1.nis = t4.nis)
                LEFT JOIN jadwal t5 ON (t1.id_jadwal = t5.id_jadwal)
                WHERE YEAR(t1.tgl) = ?
                AND MONTH(t1.tgl) = ?
                AND t1.status = ?
                ORDER BY t5.kode_jadwal";
        $query = $this->db->query($sql, array($tahun, $bulan, $status));
        return $query->result_array();
      
  
    }
	
	  public function get_count($tahun, $bulan, $status){
		$sql = "SELECT tgl, count(id_registrasi) as id_registrasi 
				FROM registrasi
				WHERE YEAR(tgl) = ?
                AND MONTH(tgl) = ?
				AND status = ?";
		  $query = $this->db->query($sql, array($tahun, $bulan, $status));
		return $query->row()->id_registrasi;
	}

}

/* End of file Lapregistrasi_model.php */
/* Location: ./application/models/Lapregistrasi_model.php */