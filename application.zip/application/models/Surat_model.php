<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Surat_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	// untuk list data surat
	public function listing(){
		$this->db->select('*');
		$this->db->from('surat');
		$this->db->order_by('id_surat', 'asc');
		$query = $this->db->get();
		return $query->result();

	}
	
	// Detail
	public function detail($id_surat){
		$this->db->select('*');
		$this->db->from('surat');
		$this->db->where('id_surat', $id_surat);
		$this->db->order_by('id_surat', 'asc');
		$query = $this->db->get();
		return $query->row();
	}

	public function add($data){
		$this->db->insert('surat', $data);
	}
	
		// Edit
	public function edit($data){
		$this->db->where('id_surat', $data['id_surat']);	
		$this->db->update('surat', $data);
	}

	// Delete
	public function delete($data){
		$this->db->where('id_surat', $data['id_surat']);
		$this->db->delete('surat', $data);
	}


}

/* End of file Surat_model.php */
/* Location: ./application/models/Surat_model.php */