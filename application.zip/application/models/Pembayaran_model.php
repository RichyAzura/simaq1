<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pembayaran_model extends CI_Model {
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	// Listing all Pembayaran
	public function listing(){
		$this->db->select('pembayaran.id_pembayaran, pembayaran.nis, pembayaran.bulan, pembayaran.tgl_pembayaran, pembayaran.spp, pembayaran.status
		 , santri.nama_santri, periode.semester, periode.thn_akademik');
		$this->db->from('pembayaran');
		$this->db->join('santri', 'santri.nis = pembayaran.nis', 'left');
		$this->db->join('periode', 'periode.kode_periode = pembayaran.kode_periode', 'left');
		$this->db->order_by('id_pembayaran', 'asc');
		$query = $this->db->get();
		return $query->result();
	}

	// Detail Jadwal
	public function detail($id_pembayaran){
		$this->db->select('*');
		 $this->db->select('(SELECT santri.nama_santri from pembayaran, santri WHERE pembayaran.nis = santri.nis AND pembayaran.id_pembayaran  = '.$id_pembayaran.') as sa');
		 $this->db->select('(SELECT periode.semester from pembayaran, periode WHERE pembayaran.kode_periode = periode.kode_periode AND pembayaran.id_pembayaran = '.$id_pembayaran.') as sm'); 
		$this->db->select('(SELECT periode.thn_akademik from pembayaran, periode WHERE pembayaran.kode_periode = periode.kode_periode AND pembayaran.id_pembayaran = '.$id_pembayaran.') as pr'); 
		$this->db->from('pembayaran');
		$this->db->where('pembayaran.id_pembayaran', $id_pembayaran);
		$this->db->order_by('id_pembayaran', 'asc');
		$query = $this->db->get();
		return $query->row();
	}

	// Add Jadwal
	public function add($data){
		$this->db->insert('pembayaran', $data);
	}

	// Edit Jadwal
	public function edit($data){
		$this->db->where('id_pembayaran', $data['id_pembayaran']);	
		$this->db->update('pembayaran', $data);
	}

	// Delete Jadwal
	public function delete($data){
		$this->db->where('id_pembayaran', $data['id_pembayaran']);
		$this->db->delete('pembayaran', $data);
	}

	public function get_sum(){
		$sql = "SELECT sum(spp) as spp from pembayaran";
		$result = $this->db->query($sql);
		return $result->row()->spp;
	}
	
	// public function get_count(){
	// 	$sql = "SELECT count(id_pembayaran) as id_pembayaran from pembayaran";
	// 	$result = $this->db->query($sql);
	// 	return $result->row()->id_pembayaran;
	// }

}

/* End of file Pembayaran_model.php */
/* Location: ./application/models/Pembayaran_model.php */