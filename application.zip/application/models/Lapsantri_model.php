<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lapsantri_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function getListSantri()
    {
      $query = $this->db->query('SELECT * FROM santri');
        return $query->result_array();
    }

     public function getDetailSantri($nis, $limit = 0)
    {
 
        $sql = "SELECT nis,nama_santri, tgl_lahir, jk, alamat, pendidikan, kelas, jespem, totjuz
                FROM santri";
        if ($nis) {
            $sql .= " WHERE nis = ?";
        }
        if ($limit) {
            $sql .= " ORDER BY kelas LIMIT ".$limit;
        }
        $query = $this->db->query($sql, $nis);
        return $query->result_array();
    }

     public function getDetailSantribyKelas($kelas, $jk)
    {
        $sql = "SELECT nis,nama_santri, tgl_lahir, jk, alamat, pendidikan, kelas, jespem, totjuz
                FROM santri
                WHERE kelas = ?
                AND jk = ?";
        $query = $this->db->query($sql, array($kelas, $jk));
        return $query->result_array();
    }

    public function get_count($kelas, $jk){
		$sql = "SELECT count(kelas) as kelas, count(jk) as jk  
				FROM santri
				WHERE kelas = ?
				AND jk = ?";
		  $query = $this->db->query($sql, array($kelas, $jk));
		return $query->row()->kelas;
		return $query->row()->jk;
	}
	 
	  public function displaydata($kelas,$jk){
	  	$kelas =$this->input->post('kelas');
        $jk =$this->input->post('jk');
      $query=$this->db->query("SELECT nis,nama_santri, tgl_lahir, jk, alamat, pendidikan, kelas, jespem
                FROM santri WHERE kelas = '$kelas' AND jk = '$jk'");
      if($query->num_rows()>0){
        return $query->result_array();
      }
    } 

}

/* End of file Lapsantri_model.php */
/* Location: ./application/models/Lapsantri_model.php */