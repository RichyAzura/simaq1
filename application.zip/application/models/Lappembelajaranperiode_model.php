<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lappembelajaranperiode_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function getListPembelajaran()
    {
      $query = $this->db->query('SELECT * FROM pembelajaran');
        return $query->result_array();
    }

    public function getListKelas()
    {
      $query = $this->db->query('SELECT * FROM kelas');
        return $query->result_array();
    }

     public function getListJenisKelas()
    {
      $query = $this->db->query('SELECT * FROM jenis_kelas');
        return $query->result_array();
    }

      public function getListGuru()
    {
      $query = $this->db->query('SELECT * FROM guru');
        return $query->result_array();
    }

     public function getListJadwal()
    {
      $query = $this->db->query('SELECT * FROM jadwal');
        return $query->result_array();
    }


   public function getDetailPembelajaran($id_pembelajaran, $limit = 0)
    {
        $sql = "SELECT t1.tgl, t2.nama_santri, t3.id_suratselesai, t3.id_juzselesai, t4.nama_surat, t5.nama_juz,t8.id_guru,t8.nama_guru,t6.kode_kelas,t10.kode_jadwal, t12.semester, t12.thn_akademik, DATE_FORMAT(t1.tgl, '%b') `month`, DATE_FORMAT(t1.tgl, '%d') `day`
                FROM pembelajaran t3
                LEFT JOIN pertemuan t1 ON (t1.id_pertemuan = t3.id_pertemuan)
                LEFT JOIN santri t2 ON (t2.nis = t3.nis)
                LEFT JOIN surat t4 ON  (t4.id_surat = t3.id_suratselesai)
                LEFT JOIN juz t5 ON  (t5.id_juz = t3.id_juzselesai)                   
                LEFT JOIN kelas t6 ON (t6.id_kelas = t1.id_kelas)
                LEFT JOIN kelas_santri t11 ON (t2.nis = t11.nis)
                LEFT JOIN guru t8 ON (t8.id_guru = t6.id_guru)        
                LEFT JOIN jadwal t10 ON (t10.id_jadwal = t11.id_jadwal)   
                 LEFT JOIN periode t12 ON (t12.kode_periode = t11.kode_periode) ";

        if ($id_pembelajaran) {
            $sql .= " WHERE t3.id_pembelajaran = ?";
        }
        if ($limit) {
            $sql .= " ORDER BY t1.tgl LIMIT ".$limit;
        }
        $query = $this->db->query($sql, $id_pembelajaran);
        return $query->result_array();
    }

     public function getDetailPembelajaranByDate($tahun, $bulan)
    {
        $sql = "SELECT t1.tgl, t2.nama_santri, t2.totjuz, t3.id_suratselesai, t3.id_juzselesai, t4.nama_surat, t5.nama_juz,t8.id_guru, t8.nama_guru,t6.kode_kelas,t10.kode_jadwal, t12.semester, t12.thn_akademik, DATE_FORMAT(t1.tgl, '%b') `month`, DATE_FORMAT(t1.tgl, '%d') `day`
                FROM pembelajaran t3
                LEFT JOIN pertemuan t1 ON (t1.id_pertemuan = t3.id_pertemuan)
                LEFT JOIN santri t2 ON (t2.nis = t3.nis)
                LEFT JOIN surat t4 ON  (t4.id_surat = t3.id_suratselesai)
                LEFT JOIN juz t5 ON  (t5.id_juz = t3.id_juzselesai)                   
                LEFT JOIN kelas t6 ON (t6.id_kelas = t1.id_kelas)
                  LEFT JOIN kelas_santri t11 ON (t2.nis = t11.nis)
                LEFT JOIN guru t8 ON (t8.id_guru = t6.id_guru)        
                LEFT JOIN jadwal t10 ON (t10.id_jadwal = t11.id_jadwal)   
                 LEFT JOIN periode t12 ON (t12.kode_periode = t11.kode_periode)   
                WHERE YEAR(t1.tgl) = ?
                AND MONTH(t1.tgl) = ?
                ORDER BY t10.kode_jadwal";
        $query = $this->db->query($sql, array($tahun, $bulan));
        return $query->result_array();
    }

     public function getDetailPembelajaranByGuru($tahun, $bulan, $id_guru)
    {
        $sql = "SELECT t1.tgl, t2.nama_santri, t3.id_suratselesai, t3.id_juzselesai, t3.totjuz,t4.nama_surat, t5.nama_juz,t8.id_guru, t8.nama_guru,t6.kode_kelas,t10.kode_jadwal, t12.semester, t12.thn_akademik, DATE_FORMAT(t1.tgl, '%b') `month`, DATE_FORMAT(t1.tgl, '%d') `day`
                FROM pembelajaran t3
                LEFT JOIN pertemuan t1 ON (t1.id_pertemuan = t3.id_pertemuan)
                LEFT JOIN santri t2 ON (t2.nis = t3.nis)
                LEFT JOIN surat t4 ON  (t4.id_surat = t3.id_suratselesai)
                LEFT JOIN juz t5 ON  (t5.id_juz = t3.id_juzselesai)                   
                LEFT JOIN kelas t6 ON (t6.id_kelas = t1.id_kelas)
                  LEFT JOIN kelas_santri t11 ON (t2.nis = t11.nis)
                LEFT JOIN guru t8 ON (t8.id_guru = t6.id_guru)        
                LEFT JOIN jadwal t10 ON (t10.id_jadwal = t11.id_jadwal)   
                 LEFT JOIN periode t12 ON (t12.kode_periode = t11.kode_periode)   
                WHERE YEAR(t1.tgl) = ?
                AND MONTH(t1.tgl) = ?
                AND t8.id_guru = ?
                ORDER BY t10.kode_jadwal";
       	$id_guru = $this->session->id_guru;
        $query = $this->db->query($sql, array($tahun, $bulan, $id_guru));
        return $query->result_array();
    }


	 



}

/* End of file Lappembelajaranperiode_model.php */
/* Location: ./application/models/Lappembelajaranperiode_model.php */