<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_model extends CI_Model {

	public function getCountDashboard($status = NULL){
		$sql = "SELECT *
				FROM registrasi";
		if($status){
			$sql .= " WHERE status = ?";  
		}
		$query = $this->db->query($sql, $status);
		return $query->num_rows(); 
	}

	public function get_count($jk){
		$sql = "SELECT count(jk) as jk  
				FROM santri
				WHERE jk = ?";
		$query = $this->db->query($sql, array($jk));
		return $query->row()->jk;
	}

	public function get_countGuru($id_guru = NULL) {
		$sql = "SELECT * 
				FROM guru";
		if($id_guru){
			$sql .= " WHERE id_guru = ?";  
		}
		$query = $this->db->query($sql, $id_guru);
		return $query->num_rows(); 
	}


}

/* End of file Dashboard_model.php */
/* Location: ./application/models/Dashboard_model.php */