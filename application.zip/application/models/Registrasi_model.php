<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Registrasi_model extends CI_Model {
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	// Listing all Registrasi
	public function listing(){
		$this->db->select('registrasi.kode_tipe, registrasi.kode_periode, registrasi.tgl, registrasi.nis, registrasi.id_jadwal, registrasi.status, registrasi.id_registrasi, tipe.nama_tipe, periode.semester,periode.thn_akademik, santri.nama_santri, santri.kelas, jadwal.kode_jadwal');
		$this->db->from('registrasi');
		$this->db->join('tipe', 'tipe.kode_tipe = registrasi.kode_tipe', 'left');
		$this->db->join('periode', 'periode.kode_periode = registrasi.kode_periode', 'left');
		$this->db->join('santri', 'santri.nis = registrasi.nis', 'left');
		$this->db->join('jadwal', 'jadwal.id_jadwal = registrasi.id_jadwal', 'left');
		$this->db->order_by('id_registrasi', 'asc');
		$query = $this->db->get();
		return $query->result();
	}


	// Detail Registrasi
	public function detail($id_registrasi){
		$this->db->select('*');
		$this->db->select('(SELECT tipe.nama_tipe from registrasi, tipe WHERE registrasi.kode_tipe = tipe.kode_tipe AND registrasi.id_registrasi = '.$id_registrasi.') as tp');
		 $this->db->select('(SELECT periode.semester from registrasi, periode WHERE registrasi.kode_periode = periode.kode_periode AND registrasi.id_registrasi = '.$id_registrasi.') as sm');
	    $this->db->select('(SELECT periode.thn_akademik from registrasi, periode WHERE registrasi.kode_periode = periode.kode_periode AND registrasi.id_registrasi = '.$id_registrasi.') as pr');
	     $this->db->select('(SELECT santri.kelas from registrasi, santri WHERE registrasi.nis = santri.nis AND registrasi.id_registrasi  = '.$id_registrasi.') as kel');
	    $this->db->select('(SELECT santri.nama_santri from registrasi, santri WHERE registrasi.nis = santri.nis AND registrasi.id_registrasi  = '.$id_registrasi.') as sa');
	     $this->db->select('(SELECT jadwal.kode_jadwal from registrasi, jadwal WHERE registrasi.id_jadwal = jadwal.id_jadwal AND registrasi.id_registrasi  = '.$id_registrasi.') as kj');
		$this->db->from('registrasi');
		$this->db->where('registrasi.id_registrasi', $id_registrasi);
		$this->db->order_by('id_registrasi', 'asc');
		$query = $this->db->get();
		return $query->row();
	}

	// Add Registrasi
	public function add($data){
		$this->db->insert('registrasi', $data);
		
	}

	// Edit Registrasi
	public function edit($data){
		$this->db->where('id_registrasi', $data['id_registrasi']);	
		$this->db->update('registrasi', $data);
	}

	// Delete Registrasi
	public function delete($data){
		$this->db->where('id_registrasi', $data['id_registrasi']);
		$this->db->delete('registrasi', $data);
	}
	
	public function get_count(){
		$sql = "SELECT count(id_registrasi) as id_registrasi from registrasi";
		$result = $this->db->query($sql);
		return $result->row()->id_registrasi;
	}

}

/* End of file Registrasi_model.php */
/* Location: ./application/models/Registrasi_model.php */