<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jenis_kelas_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	// untuk list data jenis kelas
	public function listing(){
		$this->db->select('*');
		$this->db->from('jenis_kelas');
		$this->db->order_by('kode_jeniskelas', 'asc');
		$query = $this->db->get();
		return $query->result();
	}

	// Detail
	public function detail($kode_jeniskelas){
		$this->db->select('*');
		$this->db->from('jenis_kelas');
		$this->db->where('kode_jeniskelas', $kode_jeniskelas);
		$this->db->order_by('kode_jeniskelas', 'asc');
		$query = $this->db->get();
		return $query->row();
	}

	public function add($data){
		$this->db->insert('jenis_kelas', $data);
	}
	
		// Edit
	public function edit($data){
		$this->db->where('kode_jeniskelas', $data['kode_jeniskelas']);	
		$this->db->update('jenis_kelas', $data);
	}

	// Delete
	public function delete($data){
		$this->db->where('kode_jeniskelas', $data['kode_jeniskelas']);
		$this->db->delete('jenis_kelas', $data);
	}


}

/* End of file Jeskel_model.php */
/* Location: ./application/models/Jeskel_model.php */