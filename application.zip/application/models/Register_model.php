<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register_model extends CI_Model {

	 function register($nama_user,$email,$username,$password,$level)
  {
     if ($level == "Admin" || $level == "Bendahara" || $level == "Wakbid" || $level == "Guru" || $level == "Ketua") {
      $this->db->select('*');
      $this->db->from('user');
      $this->db->where('username',$username);
      $querycek = $this->db->get();

      if ($querycek->num_rows()==0) {
        $data = array(
        	"nama_user" => $nama_user,
          "email" => $email,
          "username" => $username,
          "password" => sha1($password),
          "level" => $level
        );

        $query = $this->db->insert('user', $data); // Untuk mengeksekusi perintah insert data

        if ($query) {
          return true;
        } else {
          return false;
        }

      } else {
        return false;
      }



    }
  }

}

/* End of file Register_model.php */
/* Location: ./application/models/Register_model.php */