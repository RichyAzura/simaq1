<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {


	// untuk load database
	public function __construct()
	{
		parent::__construct();
		
		$this->load->database();
	}

	// untuk list data user
	public function listing(){
		$this->db->select('user.id_user, user.nama_user, user.email, user.username, user.password, user.level, user.nis, user.id_guru, santri.nis, guru.id_guru');
		$this->db->from('user');
		$this->db->join('santri', 'santri.nis = user.nis', 'left');
		$this->db->join('guru', 'guru.id_guru = user.id_guru', 'left');
		$this->db->order_by('id_user', 'asc');
		$query = $this->db->get();
		return $query->result();

	}
	
	// Detail
	public function detail($id_user){
		$this->db->select('*');
		$this->db->from('user');
		$this->db->where('id_user', $id_user);
		$this->db->order_by('id_user', 'asc');
		$query = $this->db->get();
		return $query->row();
	}

	public function add($data){
		$this->db->insert('user', $data);
	}
	
		// Edit
	public function edit($data){
		$this->db->where('id_user', $data['id_user']);	
		$this->db->update('user', $data);
	}

	// Delete
	public function delete($data){
		$this->db->where('id_user', $data['id_user']);
		$this->db->delete('user', $data);
	}

	public function get_count(){
		$sql = "SELECT count(id_user) as id_user from user";
		$result = $this->db->query($sql);
		return $result->row()->id_user;
	}
}

/* End of file User_model.php */
/* Location: ./application/models/User_model.php */