<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Shift_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	// untuk list data shift
	public function listing(){
		$this->db->select('*');
		$this->db->from('shift');
		$this->db->order_by('kode_shift', 'asc');
		$query = $this->db->get();
		return $query->result();

	}
	
	// Detail
	public function detail($kode_shift){
		$this->db->select('*');
		$this->db->from('shift');
		$this->db->where('kode_shift', $kode_shift);
		$this->db->order_by('kode_shift', 'asc');
		$query = $this->db->get();
		return $query->row();
	}

	public function add($data){
		$this->db->insert('shift', $data);
	}
	
		// Edit
	public function edit($data){
		$this->db->where('kode_shift', $data['kode_shift']);	
		$this->db->update('shift', $data);
	}

	// Delete
	public function delete($data){
		$this->db->where('kode_shift', $data['kode_shift']);
		$this->db->delete('shift', $data);
	}


}

/* End of file Shift_model.php */
/* Location: ./application/models/Shift_model.php */