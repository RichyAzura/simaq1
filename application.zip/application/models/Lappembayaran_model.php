<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lappembayaran_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function getListPembayaran()
    {
      $query = $this->db->query('SELECT * FROM pembayaran');
        return $query->result_array();
    }

     public function getDetailPembayaran($id_pembayaran, $limit = 0)
    {
        $sql = "SELECT t1.id_pembayaran, t2.nama_santri, t3.semester, t3.thn_akademik, t1.bulan, t1.tgl_pembayaran,
                    t1.spp, t1.status,
                    DATE_FORMAT(t1.tgl_pembayaran, '%b') `month`, DATE_FORMAT(t1.tgl_pembayaran, '%d') `day`
                FROM pembayaran t1
                LEFT JOIN santri t2 ON (t1.nis = t2.nis)
                LEFT JOIN periode t3 ON (t1.kode_periode = t3.kode_periode)";
        if($id_pembayaran) {
            $sql .= " WHERE t1.id_pembayaran = ?";
        }
        $sql .= " ORDER BY t1.tgl_pembayaran LIMIT 5";
        $query = $this->db->query($sql, $id_pembayaran);
        return $query->result_array();
    }

     public function getDetailPembayaranByDate($tahun, $bulan)
    {
        $sql = "SELECT t1.id_pembayaran, t2.nama_santri, t3.semester, t3.thn_akademik, t1.bulan, t1.tgl_pembayaran,
                    t1.spp, t1.status,
                    DATE_FORMAT(t1.tgl_pembayaran, '%b') `month`, DATE_FORMAT(t1.tgl_pembayaran, '%d') `day`
                FROM pembayaran t1
                LEFT JOIN santri t2 ON (t1.nis = t2.nis)
                LEFT JOIN periode t3 ON (t1.kode_periode = t3.kode_periode)
                WHERE YEAR(t1.tgl_pembayaran) = ?
                AND MONTH(t1.tgl_pembayaran) = ?";
        $query = $this->db->query($sql, array($tahun, $bulan));
        return $query->result_array();
    }

     public function getCetakPembayaran($tahun, $bulan)
    {
        $sql = "SELECT t1.id_pembayaran, t2.nama_santri, t3.semester, t3.thn_akademik, t1.bulan, t1.tgl_pembayaran,
                    t1.spp, t1.status,
                    DATE_FORMAT(t1.tgl_pembayaran, '%b') `month`, DATE_FORMAT(t1.tgl_pembayaran, '%d') `day`
                FROM pembayaran t1
                LEFT JOIN santri t2 ON (t1.nis = t2.nis)
                LEFT JOIN periode t3 ON (t1.kode_periode = t3.kode_periode)
                WHERE YEAR(t1.tgl_pembayaran) = ?
                AND MONTH(t1.tgl_pembayaran) = ?";
        $query = $this->db->query($sql, array($tahun, $bulan));
        return $query->result_array();
    }

    public function get_sum($tahun, $bulan){
		$sql = "SELECT tgl_pembayaran, sum(spp) as spp 
				FROM pembayaran
				WHERE YEAR(tgl_pembayaran) = ?
                AND MONTH(tgl_pembayaran) = ?";
		  $query = $this->db->query($sql, array($tahun, $bulan));
		return $query->row()->spp;
	}

}

/* End of file Lappembayaran_model.php */
/* Location: ./application/models/Lappembayaran_model.php */