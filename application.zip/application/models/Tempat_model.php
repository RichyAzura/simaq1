<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tempat_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	// untuk list data tempat
	public function listing(){
		$this->db->select('*');
		$this->db->from('tempat');
		$this->db->order_by('kode_tempat', 'asc');
		$query = $this->db->get();
		return $query->result();

	}
	
	// Detail
	public function detail($kode_tempat){
		$this->db->select('*');
		$this->db->from('tempat');
		$this->db->where('kode_tempat', $kode_tempat);
		$this->db->order_by('kode_tempat', 'asc');
		$query = $this->db->get();
		return $query->row();
	}

	public function add($data){
		$this->db->insert('tempat', $data);
	}
	
		// Edit
	public function edit($data){
		$this->db->where('kode_tempat', $data['kode_tempat']);	
		$this->db->update('tempat', $data);
	}

	// Delete
	public function delete($data){
		$this->db->where('kode_tempat', $data['kode_tempat']);
		$this->db->delete('tempat', $data);
	}



}

/* End of file tempat_model.php */
/* Location: ./application/models/tempat_model.php */