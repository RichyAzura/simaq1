<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hari_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	// untuk list data hari
	public function listing(){
		$this->db->select('*');
		$this->db->from('hari');
		$this->db->order_by('kode_hari', 'asc');
		$query = $this->db->get();
		return $query->result();

	}
	
	// Detail
	public function detail($kode_hari){
		$this->db->select('*');
		$this->db->from('hari');
		$this->db->where('kode_hari', $kode_hari);
		$this->db->order_by('kode_hari', 'asc');
		$query = $this->db->get();
		return $query->row();
	}

	public function add($data){
		$this->db->insert('hari', $data);
	}
	
		// Edit
	public function edit($data){
		$this->db->where('kode_hari', $data['kode_hari']);	
		$this->db->update('hari', $data);
	}

	// Delete
	public function delete($data){
		$this->db->where('kode_hari', $data['kode_hari']);
		$this->db->delete('hari', $data);
	}


}

/* End of file Hari_model.php */
/* Location: ./application/models/Hari_model.php */