<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lappembelajaran_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function getListPembelajaran()
    {
      $query = $this->db->query('SELECT * FROM pembelajaran');
        return $query->result_array();
    }

      public function getDetailPembelajaran($id_pembelajaran, $limit = 0)
    {
        $sql = "SELECT t1.tgl, t2.nama_santri, t3.id_suratmulai, t3.no_ayatmulai, t3.id_juzmulai,t3.id_suratselesai, t3.no_ayatselesai, t3.id_juzselesai, t4.nama_surat as sm, t8.nama_surat as ss, t5.nama_juz as jm, t9.nama_juz as js, t3.totjuz, t3.kehadiran, t3.capai_target, t7.nama_guru,
                    DATE_FORMAT(t1.tgl, '%b') `month`, DATE_FORMAT(t1.tgl, '%d') `day`
                FROM pembelajaran t3
                LEFT JOIN pertemuan t1 ON (t1.id_pertemuan = t3.id_pertemuan)
                LEFT JOIN kelas t6 ON (t6.id_kelas = t1.id_kelas)
                LEFT JOIN guru t7 ON (t7.id_guru = t6.id_guru)
                LEFT JOIN santri t2 ON (t2.nis = t3.nis)
                LEFT JOIN surat t4 ON (t4.id_surat = t3.id_suratmulai) 
                LEFT JOIN surat t8 ON (t8.id_surat = t3.id_suratselesai)
                LEFT JOIN juz t5 ON (t5.id_juz = t3.id_juzmulai)
                LEFT JOIN juz t9 ON (t9.id_juz = t3.id_juzselesai)";
        if ($id_pembelajaran) {
            $sql .= " WHERE t3.id_pembelajaran = ?";
        }
        if ($limit) {
            $sql .= " ORDER BY t1.tgl LIMIT ".$limit;
        }
        $query = $this->db->query($sql, $id_pembelajaran);
        return $query->result_array();
    }

     public function getDetailPembelajaranbyHari($tgl,$nis)
    {
        $sql = "SELECT t1.tgl, t2.nis, t2.nama_santri, t3.id_suratmulai, t3.no_ayatmulai, t3.id_juzmulai,t3.id_suratselesai, t3.no_ayatselesai, t3.id_juzselesai, t3.totjuz, t4.nama_surat as sm, t8.nama_surat as ss, t5.nama_juz as jm, t9.nama_juz as js,t3.totjuz, t3.kehadiran, t3.capai_target, t7.nama_guru,
                    DATE_FORMAT(t1.tgl, '%b') `month`, DATE_FORMAT(t1.tgl, '%d') `day`
                FROM pembelajaran t3
                LEFT JOIN pertemuan t1 ON (t1.id_pertemuan = t3.id_pertemuan)
                LEFT JOIN kelas t6 ON (t6.id_kelas = t1.id_kelas)
                LEFT JOIN guru t7 ON (t7.id_guru = t6.id_guru)
                LEFT JOIN santri t2 ON (t2.nis = t3.nis)
                LEFT JOIN surat t4 ON (t4.id_surat = t3.id_suratmulai) 
                LEFT JOIN surat t8 ON (t8.id_surat = t3.id_suratselesai)
                LEFT JOIN juz t5 ON (t5.id_juz = t3.id_juzmulai)
                LEFT JOIN juz t9 ON (t9.id_juz = t3.id_juzselesai) 
                WHERE t1.tgl = ?
                AND t2.nis = ?";
        $nis = $this->session->nis;
        $query = $this->db->query($sql, array($tgl,$nis));
        return $query->result_array();
    }

    public function getDetailPembelajaranbyPerhari($tgl,$nis)
    {
        $sql = "SELECT t1.tgl, t2.nis, t2.nama_santri, t3.id_suratmulai, t3.no_ayatmulai, t3.id_juzmulai,t3.id_suratselesai, t3.no_ayatselesai, t3.id_juzselesai, t3.totjuz, t4.nama_surat as sm, t8.nama_surat as ss, t5.nama_juz as jm, t9.nama_juz as js, t3.kehadiran, t3.capai_target, t7.nama_guru,
                    DATE_FORMAT(t1.tgl, '%b') `month`, DATE_FORMAT(t1.tgl, '%d') `day`
                FROM pembelajaran t3
                LEFT JOIN pertemuan t1 ON (t1.id_pertemuan = t3.id_pertemuan)
                LEFT JOIN kelas t6 ON (t6.id_kelas = t1.id_kelas)
                LEFT JOIN guru t7 ON (t7.id_guru = t6.id_guru)
                LEFT JOIN santri t2 ON (t2.nis = t3.nis)
                LEFT JOIN surat t4 ON (t4.id_surat = t3.id_suratmulai) 
                LEFT JOIN surat t8 ON (t8.id_surat = t3.id_suratselesai)
                LEFT JOIN juz t5 ON (t5.id_juz = t3.id_juzmulai)
                LEFT JOIN juz t9 ON (t9.id_juz = t3.id_juzselesai) 
                WHERE t1.tgl = ?
                AND t2.nis = ?";
        // $nis = $this->session->nis;
        $query = $this->db->query($sql, array($tgl,$nis));
        return $query->result_array();
    }

    public function getDetailPembelajaranbyGuru($tgl,$id_guru)
    {
        $sql = "SELECT t1.tgl, t2.nis, t2.nama_santri, t3.id_suratmulai, t3.no_ayatmulai, t3.id_juzmulai,t3.id_suratselesai, t3.no_ayatselesai, t3.id_juzselesai, t3.totjuz, t4.nama_surat as sm, t8.nama_surat as ss, t5.nama_juz as jm, t9.nama_juz as js, t3.kehadiran, t3.capai_target, t7.id_guru, t7.nama_guru, DATE_FORMAT(t1.tgl, '%b') `month`, DATE_FORMAT(t1.tgl, '%d') `day`
                FROM pembelajaran t3
                LEFT JOIN pertemuan t1 ON (t1.id_pertemuan = t3.id_pertemuan)
                LEFT JOIN kelas t6 ON (t6.id_kelas = t1.id_kelas)
                LEFT JOIN guru t7 ON (t7.id_guru = t6.id_guru)
                LEFT JOIN santri t2 ON (t2.nis = t3.nis)
                LEFT JOIN surat t4 ON (t4.id_surat = t3.id_suratmulai) 
                LEFT JOIN surat t8 ON (t8.id_surat = t3.id_suratselesai)
                LEFT JOIN juz t5 ON (t5.id_juz = t3.id_juzmulai)
                LEFT JOIN juz t9 ON (t9.id_juz = t3.id_juzselesai) 
                WHERE t1.tgl = ?
                AND t7.id_guru = ?";
        $id_guru = $this->session->id_guru;
        $query = $this->db->query($sql, array($tgl,$id_guru));
        return $query->result_array();
    }


}

/* End of file Lappembelajaran_model.php */
/* Location: ./application/models/Lappembelajaran_model.php */