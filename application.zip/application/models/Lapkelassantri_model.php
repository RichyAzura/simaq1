<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lapkelassantri_model extends CI_Model {
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	public function getListSantri()
    {
      $query = $this->db->query('SELECT * FROM santri');
        return $query->result_array();
    }

    public function getListKelas()
    {
      $query = $this->db->query('SELECT * FROM kelas');
        return $query->result_array();
    }
    public function getListKelasSantri()
    {
      $query = $this->db->query('SELECT * FROM kelas_santri');
        return $query->result_array();
    }

      public function getListGuru()
    {
      $query = $this->db->query('SELECT * FROM guru');
        return $query->result_array();
    }

     public function getListJadwal()
    {
      $query = $this->db->query('SELECT * FROM jadwal');
        return $query->result_array();
    }

     public function getListHari()
    {
      $query = $this->db->query('SELECT * FROM hari');
        return $query->result_array();
    }

    public function getDetailKelasSantri($id_kelassantri, $limit = 0)
    {
        $sql = "SELECT t1.nama_santri, t1.kelas, t1.jk, t2.kode_jadwal, t3.nama_guru, t4.id_kelas, t4.nis,t5.kode_kelas, t6.semester, t6.thn_akademik
                FROM kelas_santri t4
                LEFT JOIN santri t1 ON (t1.nis = t4.nis)           
                LEFT JOIN kelas t5 ON (t5.id_kelas = t4.id_kelas)
                LEFT JOIN guru t3 ON (t3.id_guru = t5.id_guru)           
                LEFT JOIN jadwal t2 ON (t2.id_jadwal = t4.id_jadwal)
                LEFT JOIN periode t6 ON (t6.kode_periode = t4.kode_periode)";

        if ($id_kelassantri) {
            $sql .= " WHERE id_kelassantri = ?";
        }
        if ($limit) {
            $sql .= " ORDER BY t1.kelas LIMIT ".$limit;
        }
        $query = $this->db->query($sql, $id_kelassantri);
        return $query->result_array();
    }

     public function getDetailSantribyKelas($kelas, $jk, $id_jadwal)
    {
        $sql = "SELECT t1.nama_santri, t1.kelas, t1.jk, t2.id_jadwal,t2.kode_jadwal, t3.nama_guru, t4.id_kelas, t4.nis, t5.kode_kelas,t6.semester, t6.thn_akademik
                FROM kelas_santri t4
                LEFT JOIN santri t1 ON (t1.nis = t4.nis)           
                LEFT JOIN kelas t5 ON (t5.id_kelas = t4.id_kelas)
                LEFT JOIN guru t3 ON (t3.id_guru = t5.id_guru)           
                LEFT JOIN jadwal t2 ON (t2.id_jadwal = t4.id_jadwal)
                LEFT JOIN periode t6 ON (t6.kode_periode = t4.kode_periode)
                WHERE t1.kelas = ?
                AND t1.jk = ?
                AND t2.id_jadwal = ?";
        $query = $this->db->query($sql, array($kelas, $jk, $id_jadwal));
        return $query->result_array();
    }

    public function get_count($kelas, $jk, $id_jadwal){
		$sql = "SELECT COUNT(t1.kelas) as kelas, COUNT(t1.jk) as jk, COUNT(t2.id_jadwal) as kj
                FROM kelas_santri t4
                LEFT JOIN santri t1 ON (t1.nis = t4.nis)           
                LEFT JOIN kelas t5 ON (t5.id_kelas = t4.id_kelas)
                LEFT JOIN guru t3 ON (t3.id_guru = t5.id_guru)           
                LEFT JOIN jadwal t2 ON (t2.id_jadwal = t4.id_jadwal)
                LEFT JOIN periode t6 ON (t6.kode_periode = t4.kode_periode)
                WHERE t1.kelas = ?
                AND t1.jk = ? 
                AND t2.id_jadwal = ?";
	  $query = $this->db->query($sql, array($kelas, $jk, $id_jadwal));
		return $query->row()->kelas;
		return $query->row()->jk;
		return $query->row()->id_jadwal;
	
	}


}

/* End of file Lapkelassantri_model.php */
/* Location: ./application/models/Lapkelassantri_model.php */