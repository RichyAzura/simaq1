<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tipe_model extends CI_Model {
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	// untuk list data tipe
	public function listing(){
		$this->db->select('*');
		$this->db->from('tipe');
		$this->db->order_by('kode_tipe', 'asc');
		$query = $this->db->get();
		return $query->result();

	}
	
	// Detail
	public function detail($kode_tipe){
		$this->db->select('*');
		$this->db->from('tipe');
		$this->db->where('kode_tipe', $kode_tipe);
		$this->db->order_by('kode_tipe', 'asc');
		$query = $this->db->get();
		return $query->row();
	}

	public function add($data){
		$this->db->insert('tipe', $data);
	}
	
		// Edit
	public function edit($data){
		$this->db->where('kode_tipe', $data['kode_tipe']);	
		$this->db->update('tipe', $data);
	}

	// Delete
	public function delete($data){
		$this->db->where('kode_tipe', $data['kode_tipe']);
		$this->db->delete('tipe', $data);
	}


}

/* End of file Tipe_model.php */
/* Location: ./application/models/Tipe_model.php */