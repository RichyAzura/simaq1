<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pembelajaran_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	// Listing all pembelajaran
	public function listing(){
		$this->db->select('pembelajaran.id_pertemuan, pembelajaran.nis, pembelajaran.id_suratmulai, pembelajaran.no_ayatmulai, pembelajaran.id_juzmulai, pembelajaran.id_suratselesai,  pembelajaran.no_ayatselesai, pembelajaran.id_juzselesai, pembelajaran.totjuz, pembelajaran.kehadiran, pembelajaran.capai_target, pembelajaran.ctt, pembelajaran.id_pembelajaran, surat.nama_surat,pertemuan.id_pertemuan, pertemuan.id_kelas, pertemuan.tgl, santri.nama_santri, juz.nama_juz, kelas.kode_kelas, kelas.id_guru, user.id_guru');
		$this->db->from('pembelajaran');
		$this->db->join('pertemuan', 'pertemuan.id_pertemuan = pembelajaran.id_pertemuan', 'left');
		$this->db->join('santri', 'santri.nis = pembelajaran.nis', 'left');
		$this->db->join('surat', 'surat.id_surat = pembelajaran.id_suratmulai', 'surat.id_surat = pembelajaran.id_suratselesai', 'left');
		$this->db->join('juz', 'juz.id_juz = pembelajaran.id_juzmulai', 'juz.id_juz = pembelajaran.id_juzselesai', 'left');
		$this->db->join('kelas', 'kelas.id_kelas = pertemuan.id_kelas', 'left');
		$this->db->join('guru', 'guru.id_guru = kelas.id_guru', 'left');
		$this->db->join('user', 'user.id_guru = guru.id_guru', 'left');
		$this->db->where('user.id_guru', $this->session->userdata('id_guru'));
		$this->db->order_by('id_pembelajaran', 'asc');
		$query = $this->db->get();
		return $query->result();
	}

	// Detail pembelajaran
	public function detail($id_pembelajaran){
		$this->db->select('*');
		$this->db->select('(SELECT pertemuan.tgl from pembelajaran, pertemuan WHERE pembelajaran.id_pertemuan = pertemuan.id_pertemuan AND pembelajaran.id_pembelajaran = '.$id_pembelajaran.') as tg');
		$this->db->select('(SELECT surat.nama_surat from pembelajaran, surat WHERE pembelajaran.id_suratmulai = surat.id_surat AND pembelajaran.id_pembelajaran = '.$id_pembelajaran.') as sm');
	    $this->db->select('(SELECT juz.nama_juz from pembelajaran, juz WHERE pembelajaran.id_juzmulai = juz.id_juz AND pembelajaran.id_pembelajaran = '.$id_pembelajaran.') as jm');
	    $this->db->select('(SELECT surat.nama_surat from pembelajaran, surat WHERE pembelajaran.id_suratselesai = surat.id_surat AND pembelajaran.id_pembelajaran = '.$id_pembelajaran.') as ss');
        $this->db->select('(SELECT juz.nama_juz from pembelajaran, juz WHERE pembelajaran.id_juzselesai = juz.id_juz AND pembelajaran.id_pembelajaran = '.$id_pembelajaran.') as js');
         $this->db->select('(SELECT santri.nama_santri from pembelajaran, santri WHERE pembelajaran.nis = santri.nis AND pembelajaran.id_pembelajaran  = '.$id_pembelajaran.') as sa');
		$this->db->from('pembelajaran');
		$this->db->where('pembelajaran.id_pembelajaran', $id_pembelajaran);
		$this->db->order_by('id_pembelajaran', 'asc');
		$query = $this->db->get();
		return $query->row();
	}

	public function listingAll(){
		$this->db->select('pembelajaran.id_pertemuan, pembelajaran.nis, pembelajaran.id_suratmulai, pembelajaran.no_ayatmulai, pembelajaran.id_juzmulai, pembelajaran.id_suratselesai,  pembelajaran.no_ayatselesai, pembelajaran.id_juzselesai, pembelajaran.totjuz, pembelajaran.kehadiran, pembelajaran.capai_target, pembelajaran.ctt, pembelajaran.id_pembelajaran, surat.nama_surat,pertemuan.id_pertemuan, pertemuan.id_kelas, pertemuan.tgl, santri.nama_santri, juz.nama_juz, kelas.kode_kelas');
		$this->db->from('pembelajaran');
		$this->db->join('pertemuan', 'pertemuan.id_pertemuan = pembelajaran.id_pertemuan', 'left');
		$this->db->join('santri', 'santri.nis = pembelajaran.nis', 'left');
		$this->db->join('surat', 'surat.id_surat = pembelajaran.id_suratmulai', 'surat.id_surat = pembelajaran.id_suratselesai', 'left');
		$this->db->join('juz', 'juz.id_juz = pembelajaran.id_juzmulai', 'juz.id_juz = pembelajaran.id_juzselesai', 'left');
		$this->db->join('kelas', 'kelas.id_kelas = pertemuan.id_kelas', 'left');
		$this->db->order_by('id_pembelajaran', 'asc');
		$query = $this->db->get();
		return $query->result();
	}


	// Add pembelajaran
	public function add($data){
		$this->db->insert('pembelajaran', $data);
	}

	// Edit pembelajaran
	public function edit($data){
		$this->db->where('id_pembelajaran', $data['id_pembelajaran']);	
		$this->db->update('pembelajaran', $data);
	}

	// Delete pembelajaran
	public function delete($data){
		$this->db->where('id_pembelajaran', $data['id_pembelajaran']);
		$this->db->delete('pembelajaran', $data);
	}

	  public function getSurat(){
	  return $this->db->get("surat");
	  }

	  public function getSuratby($id_surat){
	  $this->db->select('nama_surat');
	  $this->db->where('id_surat', $id_surat);
	  $this->db->limit(1);
	  return $this->db->get("surat")->row();
	  }

	  public function getJuz(){
	  return $this->db->get("juz");
	  }

	  public function getJuzby($id_juz){
	  $this->db->select('nama_juz');
	  $this->db->where('id_juz', $id_juz);
	  $this->db->limit(1);
	  return $this->db->get("juz")->row();
	  }


}

/* End of file Pembelajaran_model.php */
/* Location: ./application/models/Pembelajaran_model.php */