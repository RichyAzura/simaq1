<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kelas_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	// Listing all Kelas
	public function listing(){
		$this->db->select('kelas.id_kelas, kelas.kode_kelas, kelas.kode_jeniskelas,  kelas.id_guru,  kelas.kode_tempat, jenis_kelas.nama_jenis, guru.nama_guru, tempat.gedung');
		$this->db->from('kelas');
		$this->db->join('jenis_kelas', 'jenis_kelas.kode_jeniskelas = kelas.kode_jeniskelas', 'left');
		$this->db->join('guru', 'guru.id_guru =  kelas.id_guru', 'left');
		$this->db->join('tempat', 'tempat.kode_tempat =  kelas.kode_tempat', 'left');
		$this->db->order_by('id_kelas', 'asc');
		$query = $this->db->get();
		return $query->result();
	}

	// Detail Kelas
	public function detail($id_kelas){
		$this->db->select('*');
		 $this->db->select('(SELECT jenis_kelas.nama_jenis from kelas, jenis_kelas WHERE kelas.kode_jeniskelas = jenis_kelas.kode_jeniskelas AND kelas.id_kelas  = '.$id_kelas.') as jk');
		$this->db->select('(SELECT guru.nama_guru from kelas, guru WHERE kelas.id_guru = guru.id_guru AND kelas.id_kelas  = '.$id_kelas.') as gr'); 
		$this->db->select('(SELECT tempat.gedung from kelas, tempat WHERE kelas.kode_tempat = tempat.kode_tempat AND kelas.id_kelas  = '.$id_kelas.') as tp'); 
		$this->db->from('kelas');
		$this->db->where('kelas.id_kelas', $id_kelas);
		$this->db->order_by('id_kelas', 'asc');
		$query = $this->db->get();
		return $query->row();
	}

	// Add Kelas
	public function add($data){
		$this->db->insert('kelas', $data);
	}

	// Edit Kelas
	public function edit($data){
		$this->db->where('id_kelas', $data['id_kelas']);	
		$this->db->update('kelas', $data);
	}

	// Delete Kelas
	public function delete($data){
		$this->db->where('id_kelas', $data['id_kelas']);
		$this->db->delete('kelas', $data);
	}

}

/* End of file Kelas_model.php */
/* Location: ./application/models/Kelas_model.php */