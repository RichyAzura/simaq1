<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jadwal_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	// Listing all Jadwal
	public function listing(){
		$this->db->select('jadwal.kode_jadwal,jadwal.kode_hari, jadwal.kode_shift, jadwal.id_jadwal, hari.nama_hari, shift.waktu');
		$this->db->from('jadwal');
		$this->db->join('hari', 'hari.kode_hari = jadwal.kode_hari', 'left');
		$this->db->join('shift', 'shift.kode_shift = jadwal.kode_shift', 'left');
		$this->db->order_by('id_jadwal', 'asc');
		$query = $this->db->get();
		return $query->result();
	}

	// Detail Jadwal
	public function detail($id_jadwal){
		$this->db->select('*');
		 $this->db->select('(SELECT hari.nama_hari from jadwal, hari WHERE jadwal.kode_hari = hari.kode_hari AND jadwal.id_jadwal  = '.$id_jadwal.') as hr');
		$this->db->select('(SELECT shift.waktu from jadwal, shift WHERE jadwal.kode_shift = shift.kode_shift AND jadwal.id_jadwal = '.$id_jadwal.') as sh'); 
		$this->db->from('jadwal');
		$this->db->where('jadwal.id_jadwal', $id_jadwal);
		$this->db->order_by('id_jadwal', 'asc');
		$query = $this->db->get();
		return $query->row();
	}

	// Add Jadwal
	public function add($data){
		$this->db->insert('jadwal', $data);
	}

	// Edit Jadwal
	public function edit($data){
		$this->db->where('id_jadwal', $data['id_jadwal']);	
		$this->db->update('jadwal', $data);
	}

	// Delete Jadwal
	public function delete($data){
		$this->db->where('id_jadwal', $data['id_jadwal']);
		$this->db->delete('jadwal', $data);
	}

}

/* End of file Jadwal_model.php */
/* Location: ./application/models/Jadwal_model.php */