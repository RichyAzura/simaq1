<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lap_registrasi extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        
        require_once APPPATH.'third_party/dompdf/dompdf_config.inc.php';

        $this->load->model('lapregistrasi_model');
        $this->load->model('registrasi_model');

         if ($this->session->userdata('level')!="Admin") {
          redirect('login');
        }
    }
    public function index()
    {
         $data = array(
            'isi'    => 'admin/laporan/lap_registrasi'
        );
        $data['tahun'] = '';
        $data['bulan'] = '';
        $data['status'] = '';
        $data['detail'] = []; 
        $this->load->view('admin/layout/wrapper', $data, FALSE);
    }

    public function filter_date()
    {
        $tahun = $this->input->post('tahun');
        $bulan = $this->input->post('bulan');
        $status= $this->input->post('status');
        
        $data = array(
            'isi'    => 'admin/laporan/lap_registrasi'
        );
        $data['tahun'] = $tahun;
        $data['bulan'] = $bulan;
        $data['status'] = $status;
        $data['detail'] = $this->lapregistrasi_model->getDetailRegistrasiByDate($tahun, $bulan, $status);
        $data['count'] = $this->lapregistrasi_model->get_count($tahun, $bulan, $status);
        $this->load->view('admin/layout/wrapper', $data, FALSE);
    }

    public function cetak_registrasi($tahun = null, $bulan = null, $status= null){
        $this->load->library('dompdf_gen');
        
        $data['tahun'] = $tahun;
        $data['bulan'] = $bulan;
        $data['status'] = $status;
      
        $data['detail'] = $this->lapregistrasi_model->getDetailRegistrasiByDate($tahun, $bulan, $status);
        $data['count'] = $this->lapregistrasi_model->get_count($tahun, $bulan, $status);
        $file = 'admin/laporan/cetak_registrasi';
        $this->load->view($file, $data);

        $paper_size ='A4';
        $orientation = 'landscape';
        $html = $this->output->get_output();
        $this->dompdf->set_paper($paper_size,$orientation);

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream("Lapregistrasi.pdf", array('Attachment' => 0));

    }


}

/* End of file Lap_registrasi.php */
/* Location: ./application/controllers/admin/Lap_registrasi.php */