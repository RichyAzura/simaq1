<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tipe extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('tipe_model'); 

		 $this->load->library('session');

	    if ($this->session->userdata('level')!="Admin") {
	      redirect('login');
	    }
	}
	public function index()
	{
		$tipe = $this->tipe_model->listing();
		$data = array(
			'title' => 'List Tipe', 
			'tipe' => $tipe,
			'isi' => 'admin/tipe/list'
		);
		$this->load->view('admin/layout/wrapper', $data, FALSE);
	}

	// tambah tipe
	public function add(){
		
		$valid = $this->form_validation;
		
		$valid->set_rules('kode_tipe', 'Kode Tipe', 'required|is_unique[tipe.kode_tipe]',
			array(
				'required'  => '%s harus diisi',
				'is_unique' => '%s sudah ada. buat kode tipe baru'
			)); 

		$valid->set_rules('nama_tipe', 'Nama Tipe', 'required',
			array('required' => '%s harus diisi' ));
			
		
		if ($valid->run()===FALSE) {
				$data = array(
				'title' => 'Add Tipe', 
				'isi' => 'admin/tipe/add'
			);

			$this->load->view('admin/layout/wrapper', $data, FALSE);
		}
		else
		{
			$i = $this->input;
			$data = array(
				'kode_tipe' => $i->post('kode_tipe'),
				'nama_tipe' => $i->post('nama_tipe')
			);
			$this->tipe_model->add($data);
			$this->session->set_flashdata('sukses', 'Data telah ditambahkan');
			redirect(base_url('admin/tipe'),'refresh');
		}
		
	}

// edit tipe
	public function edit($kode_tipe)
	{
		$tipe = $this->tipe_model->detail($kode_tipe);

		$valid = $this->form_validation;
		
		$valid->set_rules('nama_tipe', 'Nama Tipe', 'required',
			array('required' => '%s harus diisi' ));
		
		if ($valid->run()===FALSE) {
			
				$data = array(
				'title' => 'Edit Tipe', 
				'tipe' => $tipe,
				'isi' => 'admin/tipe/edit'
			);

			$this->load->view('admin/layout/wrapper', $data, FALSE);
		}
		//masuk database
		else
		{
			$i = $this->input;
			$data = array(
				'kode_tipe' => $kode_tipe,
				'nama_tipe' => $i->post('nama_tipe'),
			);
			$this->tipe_model->edit($data);
			$this->session->set_flashdata('sukses', 'Data telah diubah');
			redirect(base_url('admin/tipe'),'refresh');
		}
		//end masuk database
		
	}

	// Delete Tipe
	public function delete($kode_tipe){
		$data = array('kode_tipe' => $kode_tipe);
		$this->tipe_model->delete($data);
		$this->session->set_flashdata('sukses', 'Data Telah dihapus');
		redirect(base_url('admin/tipe'),'refresh');

	}

	//Detail Tipe
	public function detail($kode_tipe){
	$tipe = $this->tipe_model->detail($kode_tipe);
		$data = array(
			'title' => 'Detail Tipe', 
			'isi' => 'admin/tipe/detail', 
			'tipe' => $tipe
		);
		$this->load->view('admin/layout/wrapper', $data, FALSE);
	}

}

/* End of file Tipe.php */
/* Location: ./application/controllers/admin/Tipe.php */