<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hari extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//load model dg nama hari_model *huruf kecil aja
		$this->load->model('hari_model'); 
		$this->load->library('session');

	    if ($this->session->userdata('level')!="Admin") {
	      redirect('login');
	    }
	}

	public function index()
	{
		$hari = $this->hari_model->listing();
		$data = array(
			'title' => 'List Hari', 
			'hari' => $hari,
			'isi' => 'admin/hari/list'
		);
		$this->load->view('admin/layout/wrapper', $data, FALSE);
	}

	// tambah hari
	public function add(){
		
		$valid = $this->form_validation;
		
		$valid->set_rules('kode_hari', 'Kode Hari', 'required|is_unique[hari.kode_hari]',
			array(
				'required'  => '%s harus diisi',
				'is_unique' => '%s sudah ada. buat kode hari baru'
			)); 

		$valid->set_rules('nama_hari', 'Nama Hari', 'required',
			array('required' => '%s harus diisi' ));
			
		
		if ($valid->run()===FALSE) {
				$data = array(
				'title' => 'Add Hari', 
				'isi' => 'admin/hari/add'
			);

			$this->load->view('admin/layout/wrapper', $data, FALSE);
		}
		else
		{
			$i = $this->input;
			$data = array(
				'kode_hari' => $i->post('kode_hari'),
				'nama_hari' => $i->post('nama_hari')
			);
			$this->hari_model->add($data);
			$this->session->set_flashdata('sukses', 'Data telah ditambahkan');
			redirect(base_url('admin/hari'),'refresh');
		}
		
	}

// edit hari
	public function edit($kode_hari)
	{
		$hari = $this->hari_model->detail($kode_hari);

		$valid = $this->form_validation;
		
		$valid->set_rules('nama_hari', 'Nama Hari', 'required',
			array('required' => '%s harus diisi' ));
		
		if ($valid->run()===FALSE) {
			
				$data = array(
				'title' => 'Edit Hari', 
				'hari' => $hari,
				'isi' => 'admin/hari/edit'
			);

			$this->load->view('admin/layout/wrapper', $data, FALSE);
		}
		//masuk database
		else
		{
			$i = $this->input;
			$data = array(
				'kode_hari' => $kode_hari,
				'nama_hari' => $i->post('nama_hari'),
			);
			$this->hari_model->edit($data);
			$this->session->set_flashdata('sukses', 'Data telah diubah');
			redirect(base_url('admin/hari'),'refresh');
		}
		//end masuk database
		
	}

	// Delete Hari
	public function delete($kode_hari){
		$data = array('kode_hari' => $kode_hari);
		$this->hari_model->delete($data);
		$this->session->set_flashdata('sukses', 'Data Telah dihapus');
		redirect(base_url('admin/hari'),'refresh');

	}

	//Detail Hari
	public function detail($kode_hari){
	$hari = $this->hari_model->detail($kode_hari);
		$data = array(
			'title' => 'Detail Hari', 
			'isi' => 'admin/hari/detail', 
			'hari' => $hari
		);
		$this->load->view('admin/layout/wrapper', $data, FALSE);
	}

}

/* End of file Hari.php */
/* Location: ./application/controllers/admin/Hari.php */