<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Santri extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('santri_model'); 

		 $this->load->library('session');

	   if ($this->session->userdata('level')!="Admin") {
	      redirect('login');
	    }
	}
	public function index()
	{
		$santri = $this->santri_model->listing();
		$data = array(
			'title' => 'List Santri', 
			'isi' => 'admin/santri/list', 
			'santri' => $santri
		);
		$data['count'] = $this->santri_model->get_count();
		$this->load->view('admin/layout/wrapper', $data, FALSE);
	}

	// tambah santri
	public function add(){
		
		$valid = $this->form_validation;

		$valid->set_rules('nis', 'NIS', 'required|is_unique[santri.nis]',
			array(
				'required'  => '%s harus diisi',
				'is_unique' => '%s sudah ada. buat nis baru'
			));

		$valid->set_rules('nama_santri', 'Nama Lengkap', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('panggilan', 'Nama Panggilan', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('tempat', 'Tempat', 'required',
			array('required' => '%s harus diisi' ));
		
		$valid->set_rules('alamat', 'Alamat', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('pendidikan', 'Pendidikan', 'required',
			array('required' => '%s harus diisi' ));
		
		$valid->set_rules('kelas', 'Kelas', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('nama_ayah', 'Nama Ayah', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('pekerjaan_ayah', 'Pekerjaan Ayah', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('nama_ibu', 'Nama Ibu', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('pekerjaan_ibu', 'Pekerjaan Ibu', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('nohp', 'No HP', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('tujuan_masuk', 'Tujuan Masuk', 'required',
			array('required' => '%s harus diisi' ));

		if ($valid->run()===FALSE) {
				$data = array(
				'title' => 'Add Santri', 
				'isi' => 'admin/santri/add'
			);

			$this->load->view('admin/layout/wrapper', $data, FALSE);
		}
		else
		{
			$i = $this->input;
			$data = array(
				'nis' => $i->post('nis'),
				'nama_santri' => $i->post('nama_santri'),
				'panggilan' => $i->post('panggilan'),
				'tempat' => $i->post('tempat'),
				'tgl_lahir' => $i->post('tgl_lahir'),
				'jk' => $i->post('jk'),
				'alamat' => $i->post('alamat'),
				'pendidikan' => $i->post('pendidikan'),
				'kelas' => $i->post('kelas'),
				'jespem' => $i->post('jespem'),
				'nama_ayah' => $i->post('nama_ayah'),
				'pekerjaan_ayah' => $i->post('pekerjaan_ayah'),
				'nama_ibu' => $i->post('nama_ibu'),
				'pekerjaan_ibu' => $i->post('pekerjaan_ibu'),
				'nohp' => $i->post('nohp'),
				'tujuan_masuk' => $i->post('tujuan_masuk'),
			);
			$this->santri_model->add($data);
			$this->session->set_flashdata('sukses', 'Data telah ditambahkan');
			redirect(base_url('admin/santri'),'refresh');
		}
		
	}

// edit santri
	public function edit($nis)
	{
		$santri = $this->santri_model->detail($nis);

		$valid = $this->form_validation;
		
		$valid->set_rules('nama_santri', 'Nama Lengkap', 'required',
			array('required' => '%s harus diisi' ));

		
		if ($valid->run()===FALSE) {
			
				$data = array(
				'title' => 'Edit Santri', 
				'santri' => $santri,
				'isi' => 'admin/santri/edit'
			);

			$this->load->view('admin/layout/wrapper', $data, FALSE);
		}
		//masuk database
		else
		{
			$i = $this->input;
			$data = array(
				'nis' => $nis,
				'nama_santri' => $i->post('nama_santri'),
				'panggilan' => $i->post('panggilan'),
				'tempat' => $i->post('tempat'),
				'tgl_lahir' => $i->post('tgl_lahir'),
				'jk' => $i->post('jk'),
				'alamat' => $i->post('alamat'),
				'pendidikan' => $i->post('pendidikan'),
				'kelas' => $i->post('kelas'),
				'jespem' => $i->post('jespem'),
				'nama_ayah' => $i->post('nama_ayah'),
				'pekerjaan_ayah' => $i->post('pekerjaan_ayah'),
				'nama_ibu' => $i->post('nama_ibu'),
				'pekerjaan_ibu' => $i->post('pekerjaan_ibu'),
				'nohp' => $i->post('nohp'),
				'tujuan_masuk' => $i->post('tujuan_masuk'),
			);
			$this->santri_model->edit($data);
			$this->session->set_flashdata('sukses', 'Data telah diubah');
			redirect(base_url('admin/santri'),'refresh');
		}
		//end masuk database
		
	}

	// Delete Santri
	public function delete($nis){
		$data = array('nis' => $nis);
		$this->santri_model->delete($data);
		$this->session->set_flashdata('sukses', 'Data Telah dihapus');
		redirect(base_url('admin/santri'),'refresh');

	}

	//Detail Santri
	public function detail($nis){
	$santri = $this->santri_model->detail($nis);
		$data = array(
			'title' => 'Detail Santri', 
			'isi' => 'admin/santri/detail', 
			'santri' => $santri
		);
		$this->load->view('admin/layout/wrapper', $data, FALSE);
	}

	
}

/* End of file Santri.php */
/* Location: ./application/controllers/admin/Santri.php */