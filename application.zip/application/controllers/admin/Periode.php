<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Periode extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		//load model dg nama periode_model *huruf kecil aja
		$this->load->model('periode_model'); 

		//memanggil library session 

		 $this->load->library('session');

		 //jika session berlevel bukan admin maka sistem akan logout otomatis dan kembali ke halaman login

	   if ($this->session->userdata('level')!="Admin") {
	      redirect('login');
	    }
	}

	public function index()
	{
		$periode = $this->periode_model->listing(); //untuk menampilkan seluruh data periode di list
		$data = array(
			'title' => 'List Periode', 
			'periode' => $periode,
			'isi' => 'admin/periode/list'
		);
		$this->load->view('admin/layout/wrapper', $data, FALSE); //memanggil layout dan array data
	}

	// tambah periode
	public function add(){
		
		$valid = $this->form_validation; //pengecekan validasi form
		
		$valid->set_rules('kode_periode', 'Kode Periode', 'required|is_unique[periode.kode_periode]',
			array(
				'required'  => '%s harus diisi',
				'is_unique' => '%s sudah ada. buat kode periode baru'
			));
		
		$valid->set_rules('semester', 'Semester', 'required',
			array('required' => '%s harus diisi' ));
		
		$valid->set_rules('thn_akademik', 'Tahun Akademik', 'required',
			array('required' => '%s harus diisi' ));
			
		
		if ($valid->run()===FALSE) {
				$data = array(
				'title' => 'Add Periode', 
				'isi' => 'admin/periode/add'
			);

			$this->load->view('admin/layout/wrapper', $data, FALSE);
		}
		else
		{
			$i = $this->input;
			$data = array(
				'kode_periode' => $i->post('kode_periode'),
				'semester' => $i->post('semester'),
				'thn_akademik' => $i->post('thn_akademik')
			);
			$this->periode_model->add($data); //memanggil periode model function add
			$this->session->set_flashdata('sukses', 'Data telah ditambahkan');
			redirect(base_url('admin/periode'),'refresh'); //kembali ke halaman periode
		}
		
	}

// edit periode
	public function edit($kode_periode)
	{
		$periode = $this->periode_model->detail($kode_periode); //memanggil function detail di periode model

		$valid = $this->form_validation;

		$valid->set_rules('semester', 'Semester', 'required',
			array('required' => '%s harus diisi' ));
		
		$valid->set_rules('thn_akademik', 'Tahun Akademik', 'required',
			array('required' => '%s harus diisi' ));

		if ($valid->run()===FALSE) {
			
				$data = array(
				'title' => 'Edit Periode', 
				'periode' => $periode,
				'isi' => 'admin/periode/edit'
			);

			$this->load->view('admin/layout/wrapper', $data, FALSE);
		}
		//masuk database
		else
		{
			$i = $this->input;
			$data = array(
				'kode_periode' => $kode_periode,
				'semester' => $i->post('semester'),
				'thn_akademik' => $i->post('thn_akademik'),
			);
			$this->periode_model->edit($data);
			$this->session->set_flashdata('sukses', 'Data telah diubah');
			redirect(base_url('admin/periode'),'refresh');
		}
		//end masuk database
		
	}

	// Delete Periode
	public function delete($kode_periode){
		$data = array('kode_periode' => $kode_periode);
		$this->periode_model->delete($data);
		$this->session->set_flashdata('sukses', 'Data Telah dihapus');
		redirect(base_url('admin/periode'),'refresh');

	}

	//Detail Periode
	public function detail($kode_periode){
	$periode = $this->periode_model->detail($kode_periode);
		$data = array(
			'title' => 'Detail Periode', 
			'isi' => 'admin/periode/detail', 
			'periode' => $periode
		);
		$this->load->view('admin/layout/wrapper', $data, FALSE);
	}


}

/* End of file Periode.php */
/* Location: ./application/controllers/Periode.php */