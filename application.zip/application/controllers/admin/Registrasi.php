<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Registrasi extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('registrasi_model');
		$this->load->model('tipe_model');
		$this->load->model('periode_model');
		$this->load->model('santri_model');
		$this->load->model('jadwal_model');
		$this->load->model('kelas_santri_model');

		$this->load->library('session');
		if ($this->session->userdata('level')!="Admin") {
			      redirect('login');
			    }
	}
	public function index()
	{
		$registrasi = $this->registrasi_model->listing();
		$data = array(
			'title'  => 'List Registrasi',
			'registrasi' => $registrasi,
			'isi'    => 'admin/registrasi/list'
		);
		$data['count'] = $this->registrasi_model->get_count();
		$this->load->view('admin/layout/wrapper', $data, FALSE);
	}

	// Tambah Registrasi
	public function add()
	{

		// Ambil data tipe
		$tipe = $this->tipe_model->listing();

		// Ambil data periode
		$periode = $this->periode_model->listing();

		// Ambil data santri
		$santri = $this->santri_model->listing();

		// Ambil data jadwal
		$jadwal = $this->jadwal_model->listing();

		// Validasi
		$valid = $this->form_validation;

		$valid->set_rules('kode_tipe', 'Kode Tipe', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('kode_periode', 'Kode Periode', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('tgl', 'Tanggal', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('nis', 'NIS Santri', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('id_jadwal', 'ID Jadwal', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('status', 'Status', 'required',
			array('required' => '%s harus diisi' ));

		if ($valid->run()===FALSE) {
			$data = array(
				'title'    => 'Add Registrasi',
				'tipe' => $tipe,
				'periode' => $periode,
				'santri' => $santri,	
				'jadwal' => $jadwal,		
				'isi'     => 'admin/registrasi/add'
			);
			$this->load->view('admin/layout/wrapper', $data, FALSE);			
		}
		else
		{
			$i = $this->input;
			$data = array(
				'kode_tipe' => $i->post('kode_tipe'),
				'kode_periode' => $i->post('kode_periode'),
				'tgl' => $i->post('tgl'),
				'nis' => $i->post('nis'),
				'id_jadwal' => $i->post('id_jadwal'),
				'status' => $i->post('status'),
			);
			$data2 = array(
				'nis' => $i->post('nis'),
				'id_jadwal' => $i->post('id_jadwal'),
				'kode_periode' => $i->post('kode_periode')
			);
			$this->registrasi_model->add($data);
			$this->kelas_santri_model->add2($data2);
			$this->session->set_flashdata('sukses', 'Data telah ditambahkan');
			redirect(base_url('admin/registrasi'),'refresh');

		}
		// END Masuk database				
	}

	// Edit Jadwal
	public function edit($id_registrasi)
	{
		$registrasi = $this->registrasi_model->detail($id_registrasi);

		// Ambil data tipe
		$tipe = $this->tipe_model->listing();

		// Ambil data periode
		$periode = $this->periode_model->listing();

		// Ambil data santri
		$santri = $this->santri_model->listing();

		// Ambil data jadwal
		$jadwal = $this->jadwal_model->listing();


		// Validasi
		$valid = $this->form_validation;

		$valid->set_rules('kode_tipe', 'Kode Tipe', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('kode_periode', 'Kode Periode', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('tgl', 'Tanggal', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('nis', 'NIS Santri', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('id_jadwal', 'ID Jadwal', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('status', 'Status', 'required',
			array('required' => '%s harus diisi' ));

		if ($valid->run()===FALSE) {
				$data = array(
				'title'    => 'Edit Registrasi',
				'registrasi' => $registrasi,
				'tipe' => $tipe,
				'periode' => $periode,
				'santri' => $santri,	
				'jadwal' => $jadwal,					  			
				'isi'      => 'admin/registrasi/edit'
		);
		$this->load->view('admin/layout/wrapper', $data, FALSE);
		}
		else
		{
			$i = $this->input;
			$data = array(
				'id_registrasi' => $id_registrasi,
				'kode_tipe' => $i->post('kode_tipe'),
				'kode_periode' => $i->post('kode_periode'),
				'tgl' => $i->post('tgl'),
				'nis' => $i->post('nis'),
				'id_jadwal' => $i->post('id_jadwal'),
				'status' => $i->post('status'),
				
			);
			$this->registrasi_model->edit($data);

			//utk update ke tabel kelas_santri
			$this->db->set('kode_periode', $i->post('kode_periode')); 
			$this->db->set('nis', $i->post('nis'));
			$this->db->set('id_jadwal', $i->post('id_jadwal'));
			$this->db->where('kode_periode', $i->post('kode_periode2'));
			$this->db->where('nis', $i->post('nis2'));
			$this->db->where('id_jadwal', $i->post('id_jadwal2'));
			$this->db->update('kelas_santri');
			
			$this->session->set_flashdata('sukses', 'Data telah diubah');
			redirect(base_url('admin/registrasi'),'refresh');
		}
		// END Masuk database			
	}

	// Delete Registrasi
	public function delete($id_registrasi){
		$data = array('id_registrasi' => $id_registrasi);
		$this->registrasi_model->delete($data);

		$this->session->set_flashdata('sukses', 'Data Telah dihapus');
		redirect(base_url('admin/registrasi'),'refresh');

	}

	//Detail Registrasi
	public function detail($id_registrasi){
	$registrasi = $this->registrasi_model->detail($id_registrasi);
		$data = array(
			'title' => 'Detail Registrasi', 
			'registrasi' => $registrasi,
			'isi' => 'admin/registrasi/detail'

		);
		$this->load->view('admin/layout/wrapper', $data, FALSE);
	}

	public function filter_status($status){
		$data['id_registrasi'] = $id_registrasi;
		$data['detail'] = $this->registrasi_model->getDetailRegistrasi($id_registrasi);
		$this->load->view('admin/layout/wrapper', $data, FALSE);
	}


}

/* End of file Registrasi.php */
/* Location: ./application/controllers/admin/Registrasi.php */