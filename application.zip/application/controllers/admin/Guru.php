<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Guru extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('guru_model'); 
		$this->load->library('session');
		if ($this->session->userdata('level')!="Admin") {
	      redirect('login');
	    }
	}
	public function index()
	{
		$guru = $this->guru_model->listing();
		$data = array(
			'title' => 'List Guru', 
			'isi' => 'admin/guru/list', 
			'guru' => $guru
		);
		$this->load->view('admin/layout/wrapper', $data, FALSE);
	}

	// tambah guru
	public function add(){
		
		$valid = $this->form_validation;

		$valid->set_rules('nama_guru', 'Nama Guru', 'required',
			array('required' => '%s harus diisi',
				'valid_nama_guru' => '%s tidak valid'));

		$valid->set_rules('tgl_lahir', 'Tanggal Lahir', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('jk', 'Jenis Kelamin', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('alamat', 'Alamat', 'required',
			array('required' => '%s harus diisi',
				'valid_alamat' => '%s tidak valid'));

		$valid->set_rules('nohp', 'No HP', 'required',
			array('required' => '%s harus diisi',
				'valid_nohp' => '%s tidak valid'));

		$valid->set_rules('email', 'Email', 'required|valid_email',
			array('required' => '%s harus diisi',
					'valid_email' => '%s tidak valid'));

		$valid->set_rules('lulusan', 'Lulusan', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('tgl_masuk', 'Tanggal Masuk', 'required',
			array('required' => '%s harus diisi' ));
		
		$valid->set_rules('jml_hafalan', 'Jumlah hafalan', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('jabatan', 'Jabatan', 'required',
			array('required' => '%s harus diisi' ));

		if ($valid->run()===FALSE) {
				$data = array(
				'title' => 'Add Guru', 
				'isi' => 'admin/guru/add'
			);

			$this->load->view('admin/layout/wrapper', $data, FALSE);
		}
		else
		{
			$i = $this->input;
			$data = array(
				'nama_guru' => $i->post('nama_guru'),
				'tgl_lahir' => $i->post('tgl_lahir'),
				'jk' => $i->post('jk'),
				'alamat' => $i->post('alamat'),
				'nohp' => $i->post('nohp'),
				'email' => $i->post('email'),
				'lulusan' => $i->post('lulusan'),
				'tgl_masuk' => $i->post('tgl_masuk'),
				'jml_hafalan' => $i->post('jml_hafalan'),
				'jabatan' => $i->post('jabatan')
			);
			$this->guru_model->add($data);
			$this->session->set_flashdata('sukses', 'Data telah ditambahkan');
			redirect(base_url('admin/guru'),'refresh');
		}
		
	}

// edit guru
	public function edit($id_guru)
	{
		$guru = $this->guru_model->detail($id_guru);

		$valid = $this->form_validation;
		
		$valid->set_rules('nama_guru', 'Nama Guru Lengkap', 'required',
			array('required' => '%s harus diisi',
				'valid_nama_guru' => '%s tidak valid'));

		$valid->set_rules('tgl_lahir', 'Tanggal Lahir', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('jk', 'Jenis Kelamin', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('alamat', 'Alamat', 'required',
			array('required' => '%s harus diisi',
				'valid_alamat' => '%s tidak valid'));

		$valid->set_rules('nohp', 'No HP', 'required',
			array('required' => '%s harus diisi',
				'valid_nohp' => '%s tidak valid'));

		$valid->set_rules('email', 'Email', 'required|valid_email',
			array('required' => '%s harus diisi',
					'valid_email' => '%s tidak valid'));

		$valid->set_rules('lulusan', 'Lulusan', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('tgl_masuk', 'Tanggal Masuk', 'required',
			array('required' => '%s harus diisi' ));
		
		$valid->set_rules('jml_hafalan', 'Jumlah hafalan', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('jabatan', 'Jabatan', 'required',
			array('required' => '%s harus diisi' ));


		if ($valid->run()===FALSE) {
			
				$data = array(
				'title' => 'Edit Guru', 
				'guru' => $guru,
				'isi' => 'admin/guru/edit'
			);

			$this->load->view('admin/layout/wrapper', $data, FALSE);
		}
		//masuk database
		else
		{
			$i = $this->input;
			$data = array(
				'id_guru' => $id_guru,
				'nama_guru' => $i->post('nama_guru'),
				'tgl_lahir' => $i->post('tgl_lahir'),
				'jk' => $i->post('jk'),
				'alamat' => $i->post('alamat'),
				'nohp' => $i->post('nohp'),
				'email' => $i->post('email'),
				'lulusan' => $i->post('lulusan'),
				'tgl_masuk' => $i->post('tgl_masuk'),
				'jml_hafalan' => $i->post('jml_hafalan'),
				'jabatan' => $i->post('jabatan')
			);
			$this->guru_model->edit($data);
			$this->session->set_flashdata('sukses', 'Data telah diubah');
			redirect(base_url('admin/guru'),'refresh');
		}
		//end masuk database
		
	}

	// Delete Guru
	public function delete($id_guru){
		$data = array('id_guru' => $id_guru);
		$this->guru_model->delete($data);
		$this->session->set_flashdata('sukses', 'Data Telah dihapus');
		redirect(base_url('admin/guru'),'refresh');

	}

	//Detail Guru
	public function detail($id_guru){
	$guru = $this->guru_model->detail($id_guru);
		$data = array(
			'title' => 'Detail Guru', 
			'isi' => 'admin/guru/detail', 
			'guru' => $guru
		);
		$this->load->view('admin/layout/wrapper', $data, FALSE);
	}


}

/* End of file Guru.php */
/* Location: ./application/controllers/admin/Guru.php */