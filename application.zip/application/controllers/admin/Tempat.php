<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tempat extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('tempat_model'); 

		 $this->load->library('session');

	    if ($this->session->userdata('level')!="Admin") {
	      redirect('login');
	    }
	}
	public function index()
	{
		$tempat = $this->tempat_model->listing();
		$data = array(
			'title' => 'List Tempat', 
			'tempat' => $tempat,
			'isi' => 'admin/tempat/list'
		);
		$this->load->view('admin/layout/wrapper', $data, FALSE);
	}

	// tambah tempat
	public function add(){
		
		$valid = $this->form_validation;
		
		$valid->set_rules('kode_tempat', 'Kode Tempat', 'required|is_unique[tempat.kode_tempat]',
			array(
				'required'  => '%s harus diisi',
				'is_unique' => '%s sudah ada. buat kode tempat baru'
			));

		$valid->set_rules('gedung', 'Gedung', 'required',
			array('required' => '%s harus diisi' ));
		
		$valid->set_rules('ruangan', 'Ruangan', 'required',
			array('required' => '%s harus diisi' ));
		
		if ($valid->run()===FALSE) {
				$data = array(
				'title' => 'Add Tempat', 
				'isi' => 'admin/tempat/add'
			);

			$this->load->view('admin/layout/wrapper', $data, FALSE);
		}
		else
		{
			$i = $this->input;
			$data = array(
				'kode_tempat' => $i->post('kode_tempat'),
				'gedung' => $i->post('gedung'),
				'ruangan' => $i->post('ruangan')
			);
			$this->tempat_model->add($data);
			$this->session->set_flashdata('sukses', 'Data telah ditambahkan');
			redirect(base_url('admin/tempat'),'refresh');
		}
		
	}

	// edit tempat
	public function edit($kode_tempat)
	{
		$tempat = $this->tempat_model->detail($kode_tempat);

		$valid = $this->form_validation;
		
		$valid->set_rules('gedung', 'Gedung', 'required',
			array('required' => '%s harus diisi' ));
		
		$valid->set_rules('ruangan', 'Ruangan', 'required',
			array('required' => '%s harus diisi' ));
		
		if ($valid->run()===FALSE) {
			
				$data = array(
				'title' => 'Edit Tempat', 
				'tempat' => $tempat,
				'isi' => 'admin/tempat/edit'
			);

			$this->load->view('admin/layout/wrapper', $data, FALSE);
		}
		//masuk database
		else
		{
			$i = $this->input;
			$data = array(
				'kode_tempat' => $kode_tempat,
				'gedung' => $i->post('gedung'),
				'ruangan' => $i->post('ruangan')
			);
			$this->tempat_model->edit($data);
			$this->session->set_flashdata('sukses', 'Data telah diubah');
			redirect(base_url('admin/tempat'),'refresh');
		}
		//end masuk database
		
	}

	// Delete Tempat
	public function delete($kode_tempat){
		$data = array('kode_tempat' => $kode_tempat);
		$this->tempat_model->delete($data);
		$this->session->set_flashdata('sukses', 'Data Telah dihapus');
		redirect(base_url('admin/tempat'),'refresh');

	}

	//Detail Tempat
	public function detail($kode_tempat){
	$tempat = $this->tempat_model->detail($kode_tempat);
		$data = array(
			'title' => 'Detail Tempat', 
			'isi' => 'admin/tempat/detail', 
			'tempat' => $tempat
		);
		$this->load->view('admin/layout/wrapper', $data, FALSE);
	}
}

/* End of file Tempat.php */
/* Location: ./application/controllers/admin/Tempat.php */