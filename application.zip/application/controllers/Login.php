<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		  $this->load->library('session');
		  $this->load->model('login_model'); // Load login model ke controller ini

	}
	public function index()
	{

		    $this->load->view('login/list');

	}

	 public function proses_login()
  {
    $username = $this->input->post('username');
    $password = $this->input->post('password');
    $level = $this->input->post('level');


    $ceklogin = $this->login_model->login($username,$password,$level);

    	if ($level == "Admin" || $level == "Bendahara" || $level == "Wakbid" || $level == "Guru" || $level == "Ketua" || $level == "Santri") {
      if ($ceklogin) {
        foreach ($ceklogin as $row){
        	$this->session->set_userdata('nama_user', $row->nama_user);
        	$this->session->set_userdata('email', $row->email);
          $this->session->set_userdata('username', $row->username);
          $this->session->set_userdata('password', $row->password);
          $this->session->set_userdata('level', $row->level);
          $this->session->set_userdata('nis', $row->nis);
          $this->session->set_userdata('id_guru', $row->id_guru);
          
          if(isset($row->nama_santri)){
                  $this->session->set_userdata('nama_santri', $row->nama_santri);
          }

           if(isset($row->nama_guru) && isset($row->jabatan)){
              $this->session->set_userdata('nama_guru', $row->nama_guru);
              $this->session->set_userdata('jabatan', $row->jabatan);
          }
          

          if($level =='Admin') {
            redirect('admin/dashboard');
          } elseif($level =='Bendahara'){
            redirect('bendahara/dashboard');
          } elseif($level =='Wakbid') {
            redirect('wakbid/dashboard');
          }elseif($this->session->userdata('level')=='Guru'){
            redirect('guru/dashboard');
          } 
          elseif($level =="Ketua"){
            redirect('ketua/dashboard');
          }
          elseif($this->session->userdata('level')=="Santri"){
            redirect('santri/dashboard');
          }
          else{
          	  $data['pesan']="Level Salah, Silahkan Login";
        			$this->load->view('login/list',$data);
          }
        }

      } else {
        $data['pesan']="Username/Password/Level Tidak Sesuai. Masukkan Username/ Password/Level yang Benar";
        $this->load->view('login/list',$data);
      }
     
    } else{
    		$data['pesan']="Username atau Password Anda Tidak Sesuai. Masukkan Username atau Password yang Benar";
        $this->load->view('login/list',$data);
    }
      
}
  public function logout()
    {
        $this->session->sess_destroy();
        redirect('Login');
    }
}


/* End of file Login.php */
/* Location: ./application/controllers/Login.php */