<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pembayaran extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('pembayaran_model');
		$this->load->model('santri_model');
		$this->load->model('periode_model');

		if ($this->session->userdata('level')!="Bendahara") {
	      redirect('login');
	    }
	}
	public function index()
	{
		$pembayaran = $this->pembayaran_model->listing();
		$data = array(
			'title'  => 'List Pembayaran',
			'pembayaran' => $pembayaran,
			'isi'    => 'bendahara/pembayaran/list');
		$data['sum'] = $this->pembayaran_model->get_sum();
		$this->load->view('bendahara/layout/wrapper', $data, FALSE);
	}

	// Tambah Pembayaran
	public function add()
	{

		// Ambil data santri
		$santri = $this->santri_model->listing();

		// Ambil data periode
		$periode = $this->periode_model->listing();

		// Validasi
		$valid = $this->form_validation;

		$valid->set_rules('nis', 'Santri', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('kode_periode', 'Periode', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('bulan', 'Bulan', 'required',
			array('required' => '%s harus diisi',
					'valid_bulan' => '%s tidak valid'));

		$valid->set_rules('tgl_pembayaran', 'Tanggal', 'required',
			array('required' => '%s harus diisi',
					'valid_tgl_pembayaran' => '%s tidak valid'));

		$valid->set_rules('spp', 'SPP', 'required',
			array('required' => '%s harus diisi',
					'valid_spp' => '%s tidak valid'));

		$valid->set_rules('status', 'Status', 'required',
			array('required' => '%s harus diisi',
					'valid_status' => '%s tidak valid'));

		if ($valid->run()===FALSE) {
			$data = array(
				'title'    => 'Add Pembayaran',
				'santri' => $santri,
				'periode' => $periode,				  			
				'isi'      => 'bendahara/pembayaran/add'
			);
			$this->load->view('bendahara/layout/wrapper', $data, FALSE);			
		}
		else
		{
			$i = $this->input;
			$data = array(
				'nis' => $i->post('nis'),
				'kode_periode' => $i->post('kode_periode'),
				'bulan' => $i->post('bulan'),
				'tgl_pembayaran' => $i->post('tgl_pembayaran'),
				'spp' => $i->post('spp'),
				'status' => $i->post('status')
			);
			$this->pembayaran_model->add($data);
			$this->session->set_flashdata('sukses', 'Data telah ditambahkan');
			redirect(base_url('bendahara/pembayaran'),'refresh');

		}
		// END Masuk database				
	}

	// Edit Pembayaran
	public function edit($id_pembayaran)
	{
		$pembayaran = $this->pembayaran_model->detail($id_pembayaran);

		// Ambil data santri
		$santri = $this->santri_model->listing();

		// Ambil data periode
		$periode = $this->periode_model->listing();

		// Validasi
		$valid = $this->form_validation;

		$valid->set_rules('nis', 'Santri', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('kode_periode', 'Periode', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('bulan', 'Bulan', 'required',
			array('required' => '%s harus diisi',
					'valid_bulan' => '%s tidak valid'));

		$valid->set_rules('tgl_pembayaran', 'Tanggal', 'required',
			array('required' => '%s harus diisi',
					'valid_tgl_pembayaran' => '%s tidak valid'));

		$valid->set_rules('spp', 'SPP', 'required',
			array('required' => '%s harus diisi',
					'valid_spp' => '%s tidak valid'));

		$valid->set_rules('status', 'Status', 'required',
			array('required' => '%s harus diisi',
					'valid_status' => '%s tidak valid'));

		if ($valid->run()===FALSE) {
				$data = array(
				'title'    => 'Edit Pembayaran',
				'pembayaran' => $pembayaran,
				'santri' => $santri,
				'periode' => $periode,				  			
				'isi'      => 'bendahara/pembayaran/edit'
		);
		$this->load->view('bendahara/layout/wrapper', $data, FALSE);
		}
		else
		{
			$i = $this->input;
			$data = array(
				'id_pembayaran' => $id_pembayaran,
				'nis' => $i->post('nis'),
				'kode_periode' => $i->post('kode_periode'),
				'bulan' => $i->post('bulan'),
				'tgl_pembayaran' => $i->post('tgl_pembayaran'),
				'spp' => $i->post('spp'),
				'status' => $i->post('status'),
			);
			$this->pembayaran_model->edit($data);
			$this->session->set_flashdata('sukses', 'Data telah ditambahkan');
			redirect(base_url('bendahara/pembayaran'),'refresh');
		}
		// END Masuk database			
	}

	// Delete Pembayaran
	public function delete($id_pembayaran){
		$data = array('id_pembayaran' => $id_pembayaran);
		$this->pembayaran_model->delete($data);
		$this->session->set_flashdata('sukses', 'Data Telah dihapus');
		redirect(base_url('bendahara/pembayaran'),'refresh');

	}

	//Detail Pembayaran
	public function detail($id_pembayaran){
	$pembayaran = $this->pembayaran_model->detail($id_pembayaran);
		$data = array(
			'title' => 'Detail Pembayaran', 
			'isi' => 'bendahara/pembayaran/detail', 
			'pembayaran' => $pembayaran
		);
		$this->load->view('bendahara/layout/wrapper', $data, FALSE);
	}

}

/* End of file Pembayaran.php */
/* Location: ./application/controllers/bendahara/Pembayaran.php */