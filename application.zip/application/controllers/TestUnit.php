<?php

class TestUnit extends CI_Controller{
    public function _construct()
    {
        parent::_construct();
        $this->load->library('unit_test');
    }
    /**
     * 
     * @param
     * @param
     */

     private function calculateDiscount($discountRate, $originalprice)
     {
        $discount = $originalprice * $discountRate /100;
        return $originalprice - $discount;
     }

     public function testDiscount()
     {
        $test= $this->calculateDiscount(50,1000);
        $expected_result = 500;
        $test_name = 'menghitung harga discount';
        echo $this->unit->run($test, $expected_result, $test_name);
     }

}