<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pembelajaran extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('pembelajaran_model');
		$this->load->model('pertemuan_model');
		$this->load->model('santri_model');
		$this->load->model('surat_model');
		$this->load->model('juz_model');

		if ($this->session->userdata('level')!="Ketua") {
	      redirect('login');
	    }
	}
	public function index()
	{
		$pembelajaran = $this->pembelajaran_model->listingAll();
		$data = array(
			'title'  => 'List Kemajuan Hafalan',
			'pembelajaran' => $pembelajaran,
			'isi'    => 'ketua/pembelajaran/list');

		$this->load->view('ketua/layout/wrapper', $data, FALSE);
	}


	//Detail pembelajaran
	public function detail($id_pembelajaran){
	$pembelajaran = $this->pembelajaran_model->detail($id_pembelajaran);
		$data = array(
			'title' => 'Detail Pembelajaran', 
			'isi' => 'ketua/pembelajaran/detail', 
			'pembelajaran' => $pembelajaran
		);
		$this->load->view('ketua/layout/wrapper', $data, FALSE);
	}

}

/* End of file Pembelajaran.php */
/* Location: ./application/controllers/guru/Pembelajaran.php */