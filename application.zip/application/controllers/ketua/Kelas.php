<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kelas extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('kelas_model');
		$this->load->model('jenis_kelas_model');
		$this->load->model('guru_model');
		$this->load->model('tempat_model');

		if ($this->session->userdata('level')!="Ketua") {
	      redirect('login');
	    }
	}
	public function index()
	{
		$kelas = $this->kelas_model->listing();
		$data = array(
			'title'  => 'List Kelas',
			'kelas' => $kelas,
			'isi'    => 'ketua/kelas/list');

		$this->load->view('ketua/layout/wrapper', $data, FALSE);
	}

	// Tambah Kelas
	public function add()
	{
		// Ambil data jenis kelas
		$jenis_kelas = $this->jenis_kelas_model->listing();

		// Ambil data guru
		$guru = $this->guru_model->listing();

		// Ambil data tempat
		$tempat = $this->tempat_model->listing();

		// Validasi
		$valid = $this->form_validation;

		$valid->set_rules('kode_kelas', 'Kode Kelas', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('kode_jeniskelas', 'Kode Jenis Kelas', 'required',
			array('required' => '%s harus diisi' ));
		
		$valid->set_rules('id_guru', 'ID Guru', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('kode_tempat', 'Kode Tempat', 'required',
			array('required' => '%s harus diisi' ));

		if ($valid->run()===FALSE) {
			$data = array(
				'title'    => 'Add Kelas',
				'jenis_kelas' => $jenis_kelas,
				'guru' => $guru,
				'tempat' => $tempat,				  			
				'isi'      => 'ketua/kelas/add'
			);
			$this->load->view('ketua/layout/wrapper', $data, FALSE);			
		}
		else
		{
			$i = $this->input;
			$data = array(
				'kode_kelas' => $i->post('kode_kelas'),
				'kode_jeniskelas' => $i->post('kode_jeniskelas'),
				'id_guru' => $i->post('id_guru'),
				'kode_tempat' => $i->post('kode_tempat')
			);
			$this->kelas_model->add($data);
			$this->session->set_flashdata('sukses', 'Data telah ditambahkan');
			redirect(base_url('ketua/kelas'),'refresh');

		}
		// END Masuk database				
	}

	// Edit Kelas
	public function edit($id_kelas)
	{
		$kelas = $this->kelas_model->detail($id_kelas);

		// Ambil data jenis kelas
		$jenis_kelas = $this->jenis_kelas_model->listing();

		// Ambil data guru
		$guru = $this->guru_model->listing();

		// Ambil data tempat
		$tempat = $this->tempat_model->listing();

		// Validasi
		$valid = $this->form_validation;

		$valid->set_rules('kode_kelas', 'Kode Kelas', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('kode_jeniskelas', 'Kode Jenis Kelas', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('id_guru', 'ID Guru', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('kode_tempat', 'Kode Tempat', 'required',
			array('required' => '%s harus diisi' ));

		if ($valid->run()===FALSE) {
				$data = array(
				'title'    => 'Edit Kelas',
				'kelas' => $kelas,
				'jenis_kelas' => $jenis_kelas,
				'guru' => $guru,
				'tempat' => $tempat,				  			
				'isi'      => 'ketua/kelas/edit'
		);
		$this->load->view('ketua/layout/wrapper', $data, FALSE);
		}
		else
		{
			$i = $this->input;
			$data = array(
				'id_kelas' => $id_kelas,
				'kode_kelas' => $i->post('kode_kelas'),
				'kode_jeniskelas' => $i->post('kode_jeniskelas'),
				'id_guru' => $i->post('id_guru'),
				'kode_tempat' => $i->post('kode_tempat'),
			);
			$this->kelas_model->edit($data);
			$this->session->set_flashdata('sukses', 'Data telah diubah');
			redirect(base_url('ketua/kelas'),'refresh');
		}
		// END Masuk database			
	}

	// Delete Kelas
	public function delete($id_kelas){
		$data = array('id_kelas' => $id_kelas);
		$this->kelas_model->delete($data);
		$this->session->set_flashdata('sukses', 'Data Telah dihapus');
		redirect(base_url('ketua/kelas'),'refresh');

	}

	//Detail Kelas
	public function detail($id_kelas){
	$kelas = $this->kelas_model->detail($id_kelas);
		$data = array(
			'title' => 'Detail Kelas', 
			'isi' => 'ketua/kelas/detail', 
			'kelas' => $kelas
		);
		$this->load->view('ketua/layout/wrapper', $data, FALSE);
	}

}

/* End of file Kelas.php */
/* Location: ./application/controllers/ketua/Kelas.php */