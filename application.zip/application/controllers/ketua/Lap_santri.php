<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lap_santri extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		//memanggil library dompdf
		 require_once APPPATH.'third_party/dompdf/dompdf_config.inc.php';
		$this->load->model('lapsantri_model');
		$this->load->model('santri_model');

		 if ($this->session->userdata('level')!="Ketua") {
	      redirect('login');
	    }
	}
	public function index()
	{
		 $data = array(
			'isi'    => 'ketua/laporan/lap_santri'
		);
		$data['kelas'] = '';
		$data['jk'] = '';
        $data['detail'] = []; 
		$this->load->view('ketua/layout/wrapper', $data, FALSE);
	}

	public function filter_kelas()
    {
		$kelas =$this->input->post('kelas');
		$jk =$this->input->post('jk');
		
        $data = array(
			'isi'    => 'ketua/laporan/lap_santri'
		);
		$data['kelas'] = $kelas;
		$data['jk'] = $jk;
        $data['detail'] = $this->lapsantri_model->getDetailSantribyKelas($kelas,$jk);
        $data['count'] = $this->lapsantri_model->get_count($kelas, $jk);
		 $this->load->view('ketua/layout/wrapper', $data, FALSE);
    }

    public function cetak_kelas($kelas = null, $jk = null)
    {
    	 $this->load->library('dompdf_gen');

		$data['kelas'] = $kelas;
		$data['jk'] = $jk;
        $data['detail'] = $this->lapsantri_model->getDetailSantribyKelas($kelas,$jk);
        $data['count'] = $this->lapsantri_model->get_count($kelas, $jk);

        $file = 'ketua/laporan/cetak_santri';
		$this->load->view($file, $data);

		$paper_size ='A4';
        $orientation = 'landscape';
        $html = $this->output->get_output();
        $this->dompdf->set_paper($paper_size,$orientation);

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream("Lapsantri.pdf", array('Attachment' => 0));
    }
    

}

/* End of file Lap_santri.php */
/* Location: ./application/controllers/ketua/Lap_santri.php */