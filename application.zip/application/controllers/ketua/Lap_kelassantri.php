<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lap_kelassantri extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('lapkelassantri_model');
		$this->load->model('santri_model');
		$this->load->model('kelas_model');
		$this->load->model('guru_model');
		$this->load->model('hari_model');
		$this->load->model('jadwal_model');

		if ($this->session->userdata('level')!="Ketua") {
	      redirect('login');
	    }
	}
	public function index()
	{
		 $data = array(
			'isi'    => 'ketua/laporan/lap_kelassantri'
		);
		$data['kelas'] = '';
		$data['jk'] = '';
		$data['id_jadwal'] = '';
        $data['detail'] = []; 
		$this->load->view('ketua/layout/wrapper', $data, FALSE);
	}

	public function filter_kelassantri()
    {
    	// Ambil data jadwal
		$jadwal = $this->jadwal_model->listing(); 

		$kelas =$this->input->post('kelas');
		$jk =$this->input->post('jk');
		$id_jadwal =$this->input->post('id_jadwal');
		
        $data = array(
        	'jadwal' => $jadwal,
			'isi'    => 'ketua/laporan/lap_kelassantri'
		);
		$data['kelas'] = $kelas;
		$data['jk'] = $jk;
		$data['id_jadwal'] = $id_jadwal;
        $data['detail'] = $this->lapkelassantri_model->getDetailSantribyKelas($kelas, $jk, $id_jadwal);
        $data['count'] = $this->lapkelassantri_model->get_count($kelas, $jk, $id_jadwal);
		$this->load->view('ketua/layout/wrapper', $data, FALSE);
    }

    public function cetak_kelassantri($kelas = null, $jk = null, $id_jadwal = null){
        $this->load->library('dompdf_gen');
        
        $data['kelas'] = $kelas;
		$data['jk'] = $jk;
		$data['id_jadwal'] = $id_jadwal;
      
        $data['detail'] = $this->lapkelassantri_model->getDetailSantribyKelas($kelas, $jk, $id_jadwal);
        $data['count'] = $this->lapkelassantri_model->get_count($kelas, $jk, $id_jadwal);
        
        $file = 'ketua/laporan/cetak_kelassantri';
        $this->load->view($file, $data);

        $paper_size ='A4';
        $orientation = 'landscape';
        $html = $this->output->get_output();
        $this->dompdf->set_paper($paper_size,$orientation);

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream("Lapsantriperkelas.pdf", array('Attachment' => 0));

    }

}

/* End of file Lap_kelassantri.php */
/* Location: ./application/controllers/ketua/Lap_kelassantri.php */