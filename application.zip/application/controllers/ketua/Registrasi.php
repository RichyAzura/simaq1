<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Registrasi extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('registrasi_model');
		$this->load->model('tipe_model');
		$this->load->model('periode_model');
		$this->load->model('santri_model');
		$this->load->model('jadwal_model');

		 $this->load->library('session');
		if ($this->session->userdata('level')!="Ketua") {
			      redirect('login');
			    }
	}
	public function index()
	{
		$registrasi = $this->registrasi_model->listing();
		$data = array(
			'title'  => 'List Registrasi',
			'registrasi' => $registrasi,
			'isi'    => 'ketua/registrasi/list'
		);
		$data['count'] = $this->registrasi_model->get_count();
		$this->load->view('ketua/layout/wrapper', $data, FALSE);
	}

	//Detail Registrasi
	public function detail($id_registrasi){
	$registrasi = $this->registrasi_model->detail($id_registrasi);
		$data = array(
			'title' => 'Detail Registrasi', 
			'registrasi' => $registrasi,
			'isi' => 'ketua/registrasi/detail'

		);
		$this->load->view('ketua/layout/wrapper', $data, FALSE);
	}

	// public function filter_status($status){
	// 	$data['id_registrasi'] = $id_registrasi;
	// 	$data['detail'] = $this->registrasi_model->getDetailRegistrasi($id_registrasi);
	// 	$this->load->view('ketua/layout/wrapper', $data, FALSE);
	// }


}

/* End of file Registrasi.php */
/* Location: ./application/controllers/ketua/Registrasi.php */