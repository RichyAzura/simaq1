<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Santri extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('santri_model'); 

		 $this->load->library('session');

	   if ($this->session->userdata('level')!="Ketua") {
	      redirect('login');
	    }
	}
	public function index()
	{
		$santri = $this->santri_model->listing();
		$data = array(
			'title' => 'List Santri', 
			'isi' => 'ketua/santri/list', 
			'santri' => $santri
		);
		$data['count'] = $this->santri_model->get_count();
		$this->load->view('ketua/layout/wrapper', $data, FALSE);
	}

	

	//Detail Santri
	public function detail($nis){
	$santri = $this->santri_model->detail($nis);
		$data = array(
			'title' => 'Detail Santri', 
			'isi' => 'ketua/santri/detail', 
			'santri' => $santri
		);
		$this->load->view('ketua/layout/wrapper', $data, FALSE);
	}

	
}

/* End of file Santri.php */
/* Location: ./application/controllers/ketua/Santri.php */