<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lap_pembelajaranperiode extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('lappembelajaranperiode_model');
		$this->load->model('pembelajaran_model');
		$this->load->model('pertemuan_model');
		$this->load->model('santri_model');
		$this->load->model('kelas_model');
		$this->load->model('guru_model');
		$this->load->model('jenis_kelas_model');

		if ($this->session->userdata('level')!="Ketua") {
	      redirect('login');
	    }
	}
	public function index()
	{
		 $data = array(
			'isi'    => 'ketua/laporan/lap_pembelajaranperiode'
		);
		$data['tahun'] = '';
		$data['bulan'] = '';
        $data['detail'] = []; 
		$this->load->view('ketua/layout/wrapper', $data, FALSE);
	}

	 public function filter_date()
    {
        $tahun = $this->input->post('tahun');
		$bulan = $this->input->post('bulan');

		
        $data = array(
			'isi'    => 'ketua/laporan/lap_pembelajaranperiode'
		);
		$data['tahun'] = $tahun;
		$data['bulan'] = $bulan;
        $data['detail'] = $this->lappembelajaranperiode_model->getDetailPembelajaranByDate($tahun, $bulan);
		$this->load->view('ketua/layout/wrapper', $data, FALSE);
    }

     public function cetak_pembelajaranperiode($tahun = null, $bulan = null){
        $this->load->library('dompdf_gen');
        
        $data['tahun'] = $tahun;
        $data['bulan'] = $bulan;
      
        $data['detail'] = $this->lappembelajaranperiode_model->getDetailPembelajaranByDate($tahun, $bulan);
        $file = 'ketua/laporan/cetak_pembelajaranperiode';
        $this->load->view($file, $data);

        $paper_size ='A4';
        $orientation = 'landscape';
        $html = $this->output->get_output();
        $this->dompdf->set_paper($paper_size,$orientation);

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream("Lappembelajaran.pdf", array('Attachment' => 0));

    }


}

/* End of file Lap_pembelajaranperiode.php */
/* Location: ./application/controllers/ketua/Lap_pembelajaranperiode.php */