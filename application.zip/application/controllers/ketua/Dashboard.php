<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('dashboard_model');
		//load model dg nama hari_model *huruf kecil aja 
		$this->load->library('session');

	    if ($this->session->userdata('level')!="Ketua") {
	      redirect('login');
	    }
	}
	public function index()
	{
		$data = array('title' => 'Halaman Dasbor',
					  'isi' => 'ketua/dashboard/list');		
		// $data['total'] = $this->dashboard_model->getCountDashboard();
		$data['jkpr'] = $this->dashboard_model->get_count('Perempuan');
		$data['jklk'] = $this->dashboard_model->get_count('Laki-Laki');
		$data['totgr'] = $this->dashboard_model->get_countGuru();
		$this->load->view('ketua/layout/wrapper', $data, FALSE);
	}

}

/* End of file Dashboard.php */
/* Location: ./application/controllers/ketua/Dashboard.php */