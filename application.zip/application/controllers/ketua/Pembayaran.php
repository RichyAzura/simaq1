<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pembayaran extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('pembayaran_model');
		$this->load->model('santri_model');
		$this->load->model('periode_model');

		if ($this->session->userdata('level')!="Ketua") {
	      redirect('login');
	    }
	}
	public function index()
	{
		$pembayaran = $this->pembayaran_model->listing();
		$data = array(
			'title'  => 'List Pembayaran',
			'pembayaran' => $pembayaran,
			'isi'    => 'ketua/pembayaran/list');
		// $data['count'] = $this->pembayaran_model->get_count();
		$data['sum'] = $this->pembayaran_model->get_sum();
		$this->load->view('ketua/layout/wrapper', $data, FALSE);
	}

	//Detail Pembayaran
	public function detail($id_pembayaran){
	$pembayaran = $this->pembayaran_model->detail($id_pembayaran);
		$data = array(
			'title' => 'Detail Pembayaran', 
			'isi' => 'ketua/pembayaran/detail', 
			'pembayaran' => $pembayaran
		);
		$this->load->view('ketua/layout/wrapper', $data, FALSE);
	}

}

/* End of file Pembayaran.php */
/* Location: ./application/controllers/ketua/Pembayaran.php */