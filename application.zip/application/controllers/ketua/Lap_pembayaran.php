<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lap_pembayaran extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		 $this->load->model('lappembayaran_model');

		 if ($this->session->userdata('level')!="Ketua") {
	      redirect('login');
	    }
	}
	public function index()
	{
		
        $data = array(
			'isi'    => 'ketua/laporan/lap_pembayaran'
		);
		$data['tahun'] = '';
		$data['bulan'] = '';
        $data['detail'] = []; 
		$this->load->view('ketua/layout/wrapper', $data, FALSE);
	}

	 public function filter_date()
    {
        $tahun = $this->input->post('tahun');
		$bulan = $this->input->post('bulan');
		
        $data = array(
			'isi'    => 'ketua/laporan/lap_pembayaran'
		);
		$data['tahun'] = $tahun;
		$data['bulan'] = $bulan;
        $data['detail'] = $this->lappembayaran_model->getDetailPembayaranByDate($tahun, $bulan);
        $data['sum'] = $this->lappembayaran_model->get_sum($tahun,$bulan);
		$this->load->view('ketua/layout/wrapper', $data, FALSE);
    }

    public function cetak_pembayaran($tahun = null, $bulan = null){
        $this->load->library('dompdf_gen');
        
        $data['tahun'] = $tahun;
        $data['bulan'] = $bulan;
      
        $data['detail'] = $this->lappembayaran_model->getDetailPembayaranByDate($tahun, $bulan);
        $data['sum'] = $this->lappembayaran_model->get_sum($tahun,$bulan);
        $file = 'ketua/laporan/cetak_pembayaran';
        $this->load->view($file, $data);

        $paper_size ='A4';
        $orientation = 'landscape';
        $html = $this->output->get_output();
        $this->dompdf->set_paper($paper_size,$orientation);

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream("Lappembayaran.pdf", array('Attachment' => 0));

    }

}

/* End of file Lap_pembayaran.php */
/* Location: ./application/controllers/ketua/Lap_pembayaran.php */