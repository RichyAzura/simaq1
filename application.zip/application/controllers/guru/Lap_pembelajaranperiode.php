<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lap_pembelajaranperiode extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('lappembelajaranperiode_model');
		$this->load->model('pembelajaran_model');
		$this->load->model('pertemuan_model');
		$this->load->model('santri_model');
		$this->load->model('kelas_model');
		$this->load->model('guru_model');
		$this->load->model('jenis_kelas_model');

		if ($this->session->userdata('level')!="Guru") {
	      redirect('login');
	    }
	}
	public function index()
	{
		 $data = array(
			'isi'    => 'guru/laporan/lap_pembelajaranperiode'
		);
		$data['tahun'] = '';
		$data['bulan'] = '';
		$data['id_guru'] = '';
        $data['detail'] = []; 
		$this->load->view('guru/layout/wrapper', $data, FALSE);
	}

	 public function filter_date()
    {
    		// Ambil data guru
		$guru = $this->guru_model->listing();
        $tahun = $this->input->post('tahun');
		$bulan = $this->input->post('bulan');
		$id_guru = $this->input->post('id_guru');
		
        $data = array(
        	'guru' => $guru,
			'isi'    => 'guru/laporan/lap_pembelajaranperiode'
		);
		$data['tahun'] = $tahun;
		$data['bulan'] = $bulan;
		$data['id_guru'] = $id_guru;
        $data['detail'] = $this->lappembelajaranperiode_model->getDetailPembelajaranByGuru($tahun, $bulan, $id_guru);
		$this->load->view('guru/layout/wrapper', $data, FALSE);
    }

     public function cetak_pembelajaranperiode($tahun = null, $bulan = null, $id_guru = null){
        $this->load->library('dompdf_gen');
        
        $data['tahun'] = $tahun;
        $data['bulan'] = $bulan;
        $data['id_guru'] = $id_guru;
      
         $data['detail'] = $this->lappembelajaranperiode_model->getDetailPembelajaranByGuru($tahun, $bulan, $id_guru);
        $file = 'guru/laporan/cetak_pembelajaranperiode';
        $this->load->view($file, $data);

        $paper_size ='A4';
        $orientation = 'landscape';
        $html = $this->output->get_output();
        $this->dompdf->set_paper($paper_size,$orientation);

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream("Lappembelajaran.pdf", array('Attachment' => 0));

    }


}

/* End of file Lap_pembelajaranperiode.php */
/* Location: ./application/controllers/guru/Lap_pembelajaranperiode.php */