<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Surat extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('surat_model'); 

		 $this->load->library('session');

	    if ($this->session->userdata('level')!="Guru") {
	      redirect('login');
	    }
	}
	public function index()
	{
		$surat = $this->surat_model->listing();
		$data = array(
			'title' => 'List Surat', 
			'isi' => 'guru/surat/list', 
			'surat' => $surat
		);
		$this->load->view('guru/layout/wrapper', $data, FALSE);
	}

	// tambah surat
	public function add(){
		
		$valid = $this->form_validation;
		$valid->set_rules('nama_surat', 'Nama Surat', 'required',
			array('required' => '%s harus diisi',
					'valid_nama_surat' => '%s tidak valid'));

		$valid->set_rules('jumlah_ayat', 'Email', 'required',
			array('required' => '%s harus diisi',
					'valid_jumlah_ayat' => '%s tidak valid'));

		if ($valid->run()===FALSE) {
				$data = array(
				'title' => 'Add Surat', 
				'isi' => 'guru/surat/add'
			);

			$this->load->view('guru/layout/wrapper', $data, FALSE);
		}
		else
		{
			$i = $this->input;
			$data = array(
				'nama_surat' => $i->post('nama_surat'),
				'jumlah_ayat' => $i->post('jumlah_ayat')
			);
			$this->surat_model->add($data);
			$this->session->set_flashdata('sukses', 'Data telah ditambahkan');
			redirect(base_url('guru/surat'),'refresh');
		}
		
	}

// edit surat
	public function edit($id_surat)
	{
		$surat = $this->surat_model->detail($id_surat);

		$valid = $this->form_validation;
		
		$valid->set_rules('nama_surat', 'Nama Surat', 'required',
			array('required' => '%s harus diisi',
					'valid_nama_surat' => '%s tidak valid'));

		$valid->set_rules('jumlah_ayat', 'Email', 'required',
			array('required' => '%s harus diisi',
					'valid_jumlah_ayat' => '%s tidak valid'));

		if ($valid->run()===FALSE) {
			
				$data = array(
				'title' => 'Edit Surat', 
				'surat' => $surat,
				'isi' => 'guru/surat/edit'
			);

			$this->load->view('guru/layout/wrapper', $data, FALSE);
		}
		//masuk database
		else
		{
			$i = $this->input;
			$data = array(
				'id_surat' => $id_surat,
				'nama_surat' => $i->post('nama_surat'),
				'jumlah_ayat' => $i->post('jumlah_ayat'),
			);
			$this->surat_model->edit($data);
			$this->session->set_flashdata('sukses', 'Data telah diubah');
			redirect(base_url('guru/surat'),'refresh');
		}
		//end masuk database
		
	}

	// Delete Surat
	public function delete($id_surat){
		$data = array('id_surat' => $id_surat);
		$this->surat_model->delete($data);
		$this->session->set_flashdata('sukses', 'Data Telah dihapus');
		redirect(base_url('guru/surat'),'refresh');

	}

	//Detail Surat
	public function detail($id_surat){
	$surat = $this->surat_model->detail($id_surat);
		$data = array(
			'title' => 'Detail Surat', 
			'isi' => 'guru/surat/detail', 
			'surat' => $surat
		);
		$this->load->view('guru/layout/wrapper', $data, FALSE);
	}

}

/* End of file Surat.php */
/* Location: ./application/controllers/guru/Surat.php */