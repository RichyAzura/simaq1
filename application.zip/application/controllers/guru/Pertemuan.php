<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pertemuan extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('pertemuan_model');
		$this->load->model('kelas_model');

		 $this->load->library('session');

	   if ($this->session->userdata('level')!="Guru") {
	      redirect('login');
	    }
	}
	public function index()
	{
		$pertemuan = $this->pertemuan_model->listing();
		$data = array(
			'title'  => 'List Pertemuan',
			'pertemuan' => $pertemuan,
			'isi'    => 'guru/pertemuan/list');

		$this->load->view('guru/layout/wrapper', $data, FALSE);
	}

	// Tambah Jadwal
	public function add()
	{

		// Ambil data kelas
		$kelas = $this->kelas_model->listing();

		// Validasi
		$valid = $this->form_validation;

		$valid->set_rules('id_kelas', 'ID', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('tgl', 'Tanggal', 'required',
			array('required' => '%s harus diisi' ));

		if ($valid->run()===FALSE) {
			$data = array(
				'title'    => 'Add Pertemuan',
				'kelas' => $kelas,			  			
				'isi'      => 'guru/pertemuan/add'
			);
			$this->load->view('guru/layout/wrapper', $data, FALSE);			
		}
		else
		{
			$i = $this->input;
			$data = array(
				'id_kelas' => $i->post('id_kelas'),
				'tgl' => $i->post('tgl')
			);
			$this->pertemuan_model->add($data);
			$this->session->set_flashdata('sukses', 'Data telah ditambahkan');
			redirect(base_url('guru/pertemuan'),'refresh');

		}
		// END Masuk database				
	}

	// Edit Pertemuan
	public function edit($id_pertemuan)
	{
		$pertemuan = $this->pertemuan_model->detail($id_pertemuan);

		// Ambil data kelas
		$kelas = $this->kelas_model->listing();

		// Validasi
		$valid = $this->form_validation;

		$valid->set_rules('id_kelas', 'ID', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('tgl', 'Tanggal', 'required',
			array('required' => '%s harus diisi' ));

		if ($valid->run()===FALSE) {
				$data = array(
				'title'    => 'Edit Pertemuan',
				'pertemuan' => $pertemuan,
				'kelas' => $kelas,			  			
				'isi'      => 'guru/pertemuan/edit'
		);
		$this->load->view('guru/layout/wrapper', $data, FALSE);
		}
		else
		{
			$i = $this->input;
			$data = array(
				'id_pertemuan' => $id_pertemuan,
				'id_kelas' => $i->post('id_kelas'),
				'tgl' => $i->post('tgl'),
			);
			$this->pertemuan_model->edit($data);
			$this->session->set_flashdata('sukses', 'Data telah ditambahkan');
			redirect(base_url('guru/pertemuan'),'refresh');
		}
		// END Masuk database			
	}

	// Delete Produk
	public function delete($id_pertemuan){
		$data = array('id_pertemuan' => $id_pertemuan);
		$this->pertemuan_model->delete($data);
		$this->session->set_flashdata('sukses', 'Data Telah dihapus');
		redirect(base_url('guru/pertemuan'),'refresh');

	}

	//Detail Pertemuan
	public function detail($id_pertemuan){
	$pertemuan = $this->pertemuan_model->detail($id_pertemuan);
		$data = array(
			'title' => 'Detail Pertemuan', 
			'isi' => 'guru/pertemuan/detail', 
			'pertemuan' => $pertemuan
		);
		$this->load->view('guru/layout/wrapper', $data, FALSE);
	}

}

/* End of file Pertemuan.php */
/* Location: ./application/controllers/guru/Pertemuan.php */