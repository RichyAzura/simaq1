<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pembelajaran extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('pembelajaran_model');
		$this->load->model('pertemuan_model');
		$this->load->model('santri_model');
		$this->load->model('surat_model');
		$this->load->model('juz_model');

		if ($this->session->userdata('level')!="Guru") {
	      redirect('login');
	    }
	}
	public function index()
	{
		$pembelajaran = $this->pembelajaran_model->listing();
		$data = array(
			'title'  => 'List Kemajuan Hafalan',
			'pembelajaran' => $pembelajaran,
			'isi'    => 'guru/pembelajaran/list');

		$this->load->view('guru/layout/wrapper', $data, FALSE);
	}


	// Tambah pembelajaran
	public function add()
	{
		// Ambil data pertemuan
		$pertemuan = $this->pertemuan_model->listing();

		// Ambil data santri
		$santri = $this->santri_model->listing();

		// Ambil data surat
		$surat = $this->surat_model->listing();

		// Ambil data juz
		$juz = $this->juz_model->listing();

		// Validasi
		$valid = $this->form_validation;

		$valid->set_rules('id_pertemuan', 'ID Pertemuan', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('nis', 'NIS', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('id_suratmulai', 'ID', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('no_ayatmulai', 'No Ayat Mulai', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('id_juzmulai', 'ID', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('id_suratselesai', 'ID', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('no_ayatselesai', 'No Ayat Mulai', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('id_juzselesai', 'ID', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('totjuz', 'Total Juz', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('kehadiran', 'Kehadiran', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('capai_target', 'Capai Target', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('ctt', 'Catatan', 'required',
			array('required' => '%s harus diisi' )); 

		if ($valid->run()===FALSE) {
			$data = array(
				'title'    => 'Add Kemajuan Hafalan',
				'pertemuan' => $pertemuan,
				'santri' => $santri,
				'surat' => $surat,				  			
				'juz' => $juz,
				'isi'      => 'guru/pembelajaran/add'
			);
			$this->load->view('guru/layout/wrapper', $data, FALSE);			
		}
		else
		{
			$i = $this->input;
			$data = array(
				'id_pertemuan' => $i->post('id_pertemuan'),
				'nis' => $i->post('nis'),
				'id_suratmulai' => $i->post('id_suratmulai'),
				'no_ayatmulai' => $i->post('no_ayatmulai'),
				'id_juzmulai' => $i->post('id_juzmulai'),
				'id_suratselesai' => $i->post('id_suratselesai'),
				'no_ayatselesai' => $i->post('no_ayatselesai'),
				'id_juzselesai' => $i->post('id_juzselesai'),
				'totjuz' => $i->post('totjuz'),
				'kehadiran' => $i->post('kehadiran'),
				'capai_target' => $i->post('capai_target'),
				'ctt' => $i->post('ctt')
			);
			$this->pembelajaran_model->add($data);

			//mengupdate field totjuz ke tabel santri
			$where = array('nis' => $i->post('nis'));
			$this->santri_model->update('santri', array("totjuz" => $i->post('totjuz')), $where);

			$this->session->set_flashdata('sukses', 'Data telah ditambahkan');
			redirect(base_url('guru/pembelajaran'),'refresh');

		}
		// END Masuk database				
	}

	// Edit pembelajaran
	public function edit($id_pembelajaran)
	{
		$pembelajaran = $this->pembelajaran_model->detail($id_pembelajaran);

		// Ambil data pertemuan
		$pertemuan = $this->pertemuan_model->listing();

		// Ambil data santri
		$santri = $this->santri_model->listing();

		// Ambil data surat
		$surat = $this->surat_model->listing();

		// Ambil data juz
		$juz = $this->juz_model->listing();

		// Validasi
		$valid = $this->form_validation;

		$valid->set_rules('id_pertemuan', 'ID Pertemuan', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('nis', 'NIS', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('id_suratmulai', 'ID', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('no_ayatmulai', 'No Ayat Mulai', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('id_juzmulai', 'ID', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('id_suratselesai', 'ID', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('no_ayatselesai', 'No Ayat Mulai', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('id_juzselesai', 'ID', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('totjuz', 'Total Juz', 'required',
			array('required' => '%s harus diisi' ));
		
		$valid->set_rules('kehadiran', 'Kehadiran', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('capai_target', 'Capai Target', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('ctt', 'Catatan', 'required',
			array('required' => '%s harus diisi' )); 

		if ($valid->run()===FALSE) {
				$data = array(
				'title'    => 'Edit Kemajuan Hafalan',
				'pembelajaran' => $pembelajaran,
				'pertemuan' => $pertemuan,
				'santri' => $santri,
				'surat' => $surat,		  			
				'juz' => $juz,			  			
				'isi'      => 'guru/pembelajaran/edit'
		);
		$this->load->view('guru/layout/wrapper', $data, FALSE);
		}
		else
		{
			$i = $this->input;
			$data = array(
				'id_pembelajaran' => $id_pembelajaran,
				'id_pertemuan' => $i->post('id_pertemuan'),
				'nis' => $i->post('nis'),
				'id_suratmulai' => $i->post('id_suratmulai'),
				'no_ayatmulai' => $i->post('no_ayatmulai'),
				'id_juzmulai' => $i->post('id_juzmulai'),
				'id_suratselesai' => $i->post('id_suratselesai'),
				'no_ayatselesai' => $i->post('no_ayatselesai'),
				'id_juzselesai' => $i->post('id_juzselesai'),
				'totjuz' => $i->post('totjuz'),
				'kehadiran' => $i->post('kehadiran'),
				'capai_target' => $i->post('capai_target'),
				'ctt' => $i->post('ctt'),
			);
			
			$this->pembelajaran_model->edit($data);
		
			$where = array('nis' => $i->post('nis'));
			$this->santri_model->update('santri', array("totjuz" => $i->post('totjuz')), $where);		

			$this->session->set_flashdata('sukses', 'Data telah diubah');
			redirect(base_url('guru/pembelajaran'),'refresh');
		}
		// END Masuk database			
	}

	// Delete pembelajaran
	public function delete($id_pembelajaran){
		$data = array('id_pembelajaran' => $id_pembelajaran);
		$this->pembelajaran_model->delete($data);
		$this->session->set_flashdata('sukses', 'Data Telah dihapus');
		redirect(base_url('guru/pembelajaran'),'refresh');

	}

	//Detail pembelajaran
	public function detail($id_pembelajaran){
	$pembelajaran = $this->pembelajaran_model->detail($id_pembelajaran);
		$data = array(
			'title' => 'Detail Pembelajaran', 
			'isi' => 'guru/pembelajaran/detail', 
			'pembelajaran' => $pembelajaran
		);
		$this->load->view('guru/layout/wrapper', $data, FALSE);
	}

}

/* End of file Pembelajaran.php */
/* Location: ./application/controllers/guru/Pembelajaran.php */