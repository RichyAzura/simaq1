<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lap_pembelajaran extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('lappembelajaran_model');
		$this->load->model('pembelajaran_model');
		$this->load->model('pertemuan_model');
		$this->load->model('santri_model');
		$this->load->model('guru_model');


		if ($this->session->userdata('level')!="Guru") {
	      redirect('login');
	    }
	}
	public function index()
	{
		 $data = array(
			'isi'    => 'guru/laporan/lap_pembelajaran'
		);
		$data['tgl'] = '';
		$data['id_guru'] = '';
        $data['detail'] = []; 
		$this->load->view('guru/layout/wrapper', $data, FALSE);
	}

	public function filter_pembelajaran()
    {
		$tgl =$this->input->post('tgl');
		$id_guru =$this->input->post('id_guru');
		
        $data = array(
			'isi'    => 'guru/laporan/lap_pembelajaran'
		);
		$data['tgl'] = $tgl;
		$data['id_guru'] = $id_guru;
        $data['detail'] = $this->lappembelajaran_model->getDetailPembelajaranbyGuru($tgl,$id_guru);
		$this->load->view('guru/layout/wrapper', $data, FALSE);
    }

     public function cetak_pembelajaran($tgl = null, $id_guru = null){
        $this->load->library('dompdf_gen');
        
        $data['tgl'] = $tgl;
		$data['id_guru'] = $id_guru;
      
        $data['detail'] = $this->lappembelajaran_model->getDetailPembelajaranbyGuru($tgl,$id_guru);
        $file = 'guru/laporan/cetak_pembelajaran';
        $this->load->view($file, $data);

        $paper_size ='A4';
        $orientation = 'landscape';
        $html = $this->output->get_output();
        $this->dompdf->set_paper($paper_size,$orientation);

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream("Lappembelajaranguru.pdf", array('Attachment' => 0));

    }

}

/* End of file Lap_pembelajaran.php */
/* Location: ./application/controllers/guru/Lap_pembelajaran.php */