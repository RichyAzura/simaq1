<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Juz extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('juz_model'); 
		$this->load->library('session');

    	if ($this->session->userdata('level')!="Guru") {
	      redirect('login');
	    }
	}
	public function index()
	{
		$juz = $this->juz_model->listing();
		$data = array(
			'title' => 'List Juz', 
			'isi' => 'guru/juz/list', 
			'juz' => $juz
		);
		$this->load->view('guru/layout/wrapper', $data, FALSE);
	}

	// tambah juz
	public function add(){
		
		$valid = $this->form_validation;

		$valid->set_rules('nama_juz', 'Nama Juz', 'required',
			array('required' => '%s harus diisi',
					'valid_nama_juz' => '%s tidak valid'));

		if ($valid->run()===FALSE) {
				$data = array(
				'title' => 'Add Juz', 
				'isi' => 'guru/juz/add'
			);

			$this->load->view('guru/layout/wrapper', $data, FALSE);
		}
		else
		{
			$i = $this->input;
			$data = array(
				'nama_juz' => $i->post('nama_juz')
			);
			$this->juz_model->add($data);
			$this->session->set_flashdata('sukses', 'Data telah ditambahkan');
			redirect(base_url('guru/juz'),'refresh');
		}
		
	}

// edit juz
	public function edit($id_juz)
	{
		$juz = $this->juz_model->detail($id_juz);

		$valid = $this->form_validation;
		
		$valid->set_rules('nama_juz', 'Nama Juz', 'required',
			array('required' => '%s harus diisi',
					'valid_nama_juz' => '%s tidak valid'));

		if ($valid->run()===FALSE) {
			
				$data = array(
				'title' => 'Edit Juz', 
				'juz' => $juz,
				'isi' => 'guru/juz/edit'
			);

			$this->load->view('guru/layout/wrapper', $data, FALSE);
		}
		//masuk database
		else
		{
			$i = $this->input;
			$data = array(
				'id_juz' => $id_juz,
				'nama_juz' => $i->post('nama_juz'),
			);
			$this->juz_model->edit($data);
			$this->session->set_flashdata('sukses', 'Data telah diubah');
			redirect(base_url('guru/juz'),'refresh');
		}
		//end masuk database
		
	}

	// Delete juz
	public function delete($id_juz){
		$data = array('id_juz' => $id_juz);
		$this->juz_model->delete($data);
		$this->session->set_flashdata('sukses', 'Data Telah dihapus');
		redirect(base_url('guru/juz'),'refresh');

	}

	//Detail juz
	public function detail($id_juz){
	$juz = $this->juz_model->detail($id_juz);
		$data = array(
			'title' => 'Detail Juz', 
			'isi' => 'guru/juz/detail', 
			'juz' => $juz
		);
		$this->load->view('guru/layout/wrapper', $data, FALSE);
	}

}

/* End of file Juz.php */
/* Location: ./application/controllers/guru/Juz.php */