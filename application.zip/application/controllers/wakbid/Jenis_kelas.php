<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jenis_kelas extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('jenis_kelas_model'); 

		 $this->load->library('session');

	   if ($this->session->userdata('level')!="Wakbid") {
	      redirect('login');
	    }
	}
	public function index()
	{
		$jenis_kelas = $this->jenis_kelas_model->listing();
		$data = array(
			'title' => 'List Jenis Kelas', 
			'jenis_kelas' => $jenis_kelas,
			'isi' => 'wakbid/jenis_kelas/list'
		);
		$this->load->view('wakbid/layout/wrapper', $data, FALSE);
	}

	// tambah jenis kelas
	public function add(){
		
		$valid = $this->form_validation;
		
		$valid->set_rules('kode_jeniskelas', 'Kode Jenis Kelas', 'required|is_unique[jenis_kelas.kode_jeniskelas]',
			array(
				'required'  => '%s harus diisi',
				'is_unique' => '%s sudah ada. buat kode jeniskelas baru'
			));
		
		$valid->set_rules('nama_jenis', 'Nama Jenis', 'required',
			array('required' => '%s harus diisi' ));
		
			
		
		if ($valid->run()===FALSE) {
				$data = array(
				'title' => 'Add Jenis Kelas', 
				'isi' => 'wakbid/jenis_kelas/add'
			);

			$this->load->view('wakbid/layout/wrapper', $data, FALSE);
		}
		else
		{
			$i = $this->input;
			$data = array(
				'kode_jeniskelas' => $i->post('kode_jeniskelas'),
				'nama_jenis' => $i->post('nama_jenis')
			);
			$this->jenis_kelas_model->add($data);
			$this->session->set_flashdata('sukses', 'Data telah ditambahkan');
			redirect(base_url('wakbid/jenis_kelas'),'refresh');
		}
		
	}

// edit jeniskelas
	public function edit($kode_jeniskelas)
	{
		$jenis_kelas = $this->jenis_kelas_model->detail($kode_jeniskelas);

		$valid = $this->form_validation;
		
		$valid->set_rules('nama_jenis', 'Nama Jenis', 'required',
			array('required' => '%s harus diisi' ));
		

		if ($valid->run()===FALSE) {
			
				$data = array(
				'title' => 'Edit Jenis Kelas', 
				'jenis_kelas' => $jenis_kelas,
				'isi' => 'wakbid/jenis_kelas/edit'
			);

			$this->load->view('wakbid/layout/wrapper', $data, FALSE);
		}
		//masuk database
		else
		{
			$i = $this->input;
			$data = array(
				'kode_jeniskelas' => $kode_jeniskelas,
				'nama_jenis' => $i->post('nama_jenis'),
			);
			$this->jenis_kelas_model->edit($data);
			$this->session->set_flashdata('sukses', 'Data telah diubah');
			redirect(base_url('wakbid/jenis_kelas'),'refresh');
		}
		//end masuk database
		
	}

	// Delete jeniskelas
	public function delete($kode_jeniskelas){
		$data = array('kode_jeniskelas' => $kode_jeniskelas);
		$this->jenis_kelas_model->delete($data);
		$this->session->set_flashdata('sukses', 'Data Telah dihapus');
		redirect(base_url('wakbid/jenis_kelas'),'refresh');

	}

	//Detail jeniskelas
	public function detail($kode_jeniskelas){
	$jenis_kelas = $this->jenis_kelas_model->detail($kode_jeniskelas);
		$data = array(
			'title' => 'Detail Jenis Kelas', 
			'isi' => 'wakbid/jenis_kelas/detail', 
			'jenis_kelas' => $jenis_kelas
		);
		$this->load->view('wakbid/layout/wrapper', $data, FALSE);
	}


}

/* End of file Jeskel.php */
/* Location: ./application/controllers/wakbid/Jeskel.php */