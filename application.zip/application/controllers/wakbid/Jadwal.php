<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jadwal extends CI_Controller {
	public function __construct()
	{
		parent::__construct();

		$this->load->model('jadwal_model');
		$this->load->model('hari_model');
		$this->load->model('shift_model');

		if ($this->session->userdata('level')!="Wakbid") {
	      redirect('login');
	    }
	}
	public function index()
	{
		$jadwal = $this->jadwal_model->listing();
		$data = array(
			'title'  => 'List Jadwal',
			'jadwal' => $jadwal,
			'isi'    => 'wakbid/jadwal/list');

		$this->load->view('wakbid/layout/wrapper', $data, FALSE);
	}

	// Tambah Jadwal
	public function add()
	{

		// Ambil data hari
		$hari = $this->hari_model->listing();

		// Ambil data shift
		$shift = $this->shift_model->listing();

		// Validasi
		$valid = $this->form_validation;

		$valid->set_rules('kode_jadwal', 'Kode', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('kode_hari', 'Kode', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('kode_shift', 'Kode', 'required',
			array('required' => '%s harus diisi' ));

		if ($valid->run()===FALSE) {
			$data = array(
				'title'    => 'Add Jadwal',
				'hari' => $hari,
				'shift' => $shift,				  			
				'isi'      => 'wakbid/jadwal/add'
			);
			$this->load->view('wakbid/layout/wrapper', $data, FALSE);			
		}
		else
		{
			$i = $this->input;
			$data = array(
				'kode_jadwal' => $i->post('kode_jadwal'),
				'kode_hari' => $i->post('kode_hari'),
				'kode_shift' => $i->post('kode_shift')
			);
			$this->jadwal_model->add($data);
			$this->session->set_flashdata('sukses', 'Data telah ditambahkan');
			redirect(base_url('wakbid/jadwal'),'refresh');

		}
		// END Masuk database				
	}

	// Edit Jadwal
	public function edit($id_jadwal)
	{
		$jadwal = $this->jadwal_model->detail($id_jadwal);

		// Ambil data hari
		$hari = $this->hari_model->listing();

		// Ambil data shift
		$shift = $this->shift_model->listing();

		// Validasi
		$valid = $this->form_validation;

		$valid->set_rules('kode_jadwal', 'Kode', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('kode_hari', 'Kode', 'required',
			array('required' => '%s harus diisi' ));

		$valid->set_rules('kode_shift', 'Kode', 'required',
			array('required' => '%s harus diisi' ));

		if ($valid->run()===FALSE) {
				$data = array(
				'title'    => 'Edit Jadwal',
				'jadwal' => $jadwal,
				'hari' => $hari,
				'shift' => $shift,				  			
				'isi'      => 'wakbid/jadwal/edit'
		);
		$this->load->view('wakbid/layout/wrapper', $data, FALSE);
		}
		else
		{
			$i = $this->input;
			$data = array(
				'id_jadwal' => $id_jadwal,
				'kode_jadwal' => $i->post('kode_jadwal'),
				'kode_hari' => $i->post('kode_hari'),
				'kode_shift' => $i->post('kode_shift'),
			);
			$this->jadwal_model->edit($data);
			$this->session->set_flashdata('sukses', 'Data telah diubah');
			redirect(base_url('wakbid/jadwal'),'refresh');
		}
		// END Masuk database			
	}

	// Delete Jadwal
	public function delete($id_jadwal){
		$data = array('id_jadwal' => $id_jadwal);
		$this->jadwal_model->delete($data);
		$this->session->set_flashdata('sukses', 'Data Telah dihapus');
		redirect(base_url('wakbid/jadwal'),'refresh');

	}

	//Detail Jadwal
	public function detail($id_jadwal){
	$jadwal = $this->jadwal_model->detail($id_jadwal);
		$data = array(
			'title' => 'Detail Jadwal', 
			'isi' => 'wakbid/jadwal/detail', 
			'jadwal' => $jadwal
		);
		$this->load->view('wakbid/layout/wrapper', $data, FALSE);
	}
}

/* End of file Jadwal.php */
/* Location: ./application/controllers/wakbid/Jadwal.php */