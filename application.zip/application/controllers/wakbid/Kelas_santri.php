<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kelas_santri extends CI_Controller {
	public function __construct()
	{
		//menjalankan otomatis ketika perintah class dijalankan yg dapat menginisialisasi sebuah helper, library, form, url, dll
		parent::__construct();
		$this->load->model('kelas_santri_model');
		$this->load->model('kelas_model');
		$this->load->model('santri_model');
		$this->load->model('jadwal_model');
		$this->load->model('periode_model');

		//memanggil library session yg berfungsi memelihara informasi status pengguna yg harus login terlebih dahulu
		 $this->load->library('session');

   		if ($this->session->userdata('level')!="Wakbid") {
	      redirect('login');
	    }
    }
	
	public function index()
	{
		$kelas_santri = $this->kelas_santri_model->listing();
		$data = array(
			'title'  => 'List Penentuan Kelas',
			'kelas_santri' => $kelas_santri,
			'isi'    => 'wakbid/kelas_santri/tampil');
		$data['id_jadwal'] = '';
		$data['jk'] = '';
        $data['detail'] = []; 

		$this->load->view('wakbid/layout/wrapper', $data, FALSE);
	}
	public function filter_penentuankelas()
    {
    	// Ambil data shift
		$jadwal = $this->jadwal_model->listing();

		$id_jadwal =$this->input->post('id_jadwal');

		$jk =$this->input->post('jk');
		
        $data = array(
        	'title'  => 'Data Penentuan Kelas',
        	'jadwal' => $jadwal,
			'isi'    => 'wakbid/kelas_santri/list'
		);
		$data['id_jadwal'] = $id_jadwal;
		$data['jk'] = $jk;
        $data['detail'] = $this->kelas_santri_model->getDetailPenentuanKelasbyJadwal($id_jadwal,$jk);
		$this->load->view('wakbid/layout/wrapper', $data, FALSE);
    }

     public function cetak_penentuankelas($id_jadwal = null, $jk = null){
        $this->load->library('dompdf_gen');
        
        $data['id_jadwal'] = $id_jadwal;
		$data['jk'] = $jk;
      
        $data['detail'] = $this->kelas_santri_model->getDetailPenentuanKelasbyJadwal($id_jadwal,$jk);
        $file = 'wakbid/kelas_santri/cetak_penentuankelas';
        $this->load->view($file, $data);

        $paper_size ='A4';
        $orientation = 'landscape';
        $html = $this->output->get_output();
        $this->dompdf->set_paper($paper_size,$orientation);

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream("LapPenentuanKelas.pdf", array('Attachment' => 0));

    }

	// Edit Kelas Santri
	public function edit($id_kelassantri)
	{
		$kelas_santri = $this->kelas_santri_model->detail($id_kelassantri);

		// Ambil data kelas
		$kelas = $this->kelas_model->listing();

		// Ambil data santri
		$santri = $this->santri_model->listing();

		// Ambil data santri
		$jadwal = $this->jadwal_model->listing();

		// Ambil data santri
		$periode = $this->periode_model->listing();

		// Validasi
		$valid = $this->form_validation;

		$valid->set_rules('id_kelas', 'Kelas', 'required',
			array('required' => '%s harus diisi' ));

		if ($valid->run()===FALSE) {
				$data = array(
				'title'    => 'Edit Penentuan Kelas',
				'kelas_santri' => $kelas_santri,
				'kelas' => $kelas,	
				'santri' => $santri,	
				'jadwal' => $jadwal,
				'periode' => $periode,		  			
				'isi'      => 'wakbid/kelas_santri/edit'
		);
		$this->load->view('wakbid/layout/wrapper', $data, FALSE);
		}
		else
		{
			$i = $this->input;
			$data = array(
				'id_kelassantri' => $id_kelassantri,
				'nis' => $i->post('nis'),
				'id_jadwal' => $i->post('id_jadwal'),
				'kode_periode' => $i->post('kode_periode'),
				'id_kelas' => $i->post('id_kelas'),
			);
			$this->kelas_santri_model->edit($data);
			$this->session->set_flashdata('sukses', 'Data telah ditambahkan');
			redirect(base_url('wakbid/kelas_santri'),'refresh');
		}
		// END Masuk database			
	}

	public function delete($id_kelassantri){
		$data = array('id_kelassantri' => $id_kelassantri);
		$this->kelas_santri_model->delete($data);
		$this->session->set_flashdata('sukses', 'Data Telah dihapus');
		redirect(base_url('wakbid/Kelas_santri'),'refresh');

	}


	//Detail Kelas Santri
	public function detail($id_kelassantri){
	$kelas_santri = $this->kelas_santri_model->detail($id_kelassantri);
		$data = array(
			'title' => 'Detail Penempatan Santri', 
			'isi' => 'wakbid/kelas_santri/detail', 
			'kelas_santri' => $kelas_santri
		);
		$this->load->view('wakbid/layout/wrapper', $data, FALSE);
	}

}

/* End of file Kelas_santri.php */
/* Location: ./application/controllers/wakbid/Kelas_santri.php */