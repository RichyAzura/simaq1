<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
	   $this->load->model('register_model'); // Load RegisterModel ke controller ini
      $this->load->library('session'); // Load RegisterModel ke controller ini
	}
	public function index()
	{
		
		$this->load->view('register/list');
	}

	public function proses_register()
  {
  	$nama_user = $this->input->post('nama_user');
    $email = $this->input->post('email');
    $username = $this->input->post('username');
    $password = $this->input->post('password');
    $level = $this->input->post('level');


    $cekregister = $this->register_model->register($nama_user,$email,$username,$password,$level);

    if ($level == "Admin" ||$level == "Bendahara" || $level == "Wakbid" || $level == "Guru" || $level == "ketua" ) {
      if ($cekregister) {

        $data['pesan']="Register Berhasil, Silahkan Login.";
        $this->load->view('login/list',$data);

      } else {
        $data['pesan']="Register Gagal, Akun Sudah Terdaftar, Silahkan Daftar Lagi.";
        $this->load->view('register/list',$data);
      }

    }

}

}

/* End of file Register.php */
/* Location: ./application/controllers/Register.php */